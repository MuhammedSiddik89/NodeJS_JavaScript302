const fs = require('fs'); //for reading the file
var http = require("http"); // import http core modules
var url = require("url"); // import url core modules
var qs = require('querystring');
//var formidable = require("formidable");  //for image upload
var mysql = require('mysql');
var Array =[];  // used to store data for inserting into SDGHitDesc table
var data="";

var arylength; //used in checking if line of data exists in Array
var arrayLineExistsUnit=false;
var arrayLineExistsLO=false;
var arrayLineExistsAssessment=false;
var arylnLO = na;
var arylnUnit = na;

//need to change to local variable later
//matching the students with the user searched degree
var counter = 0;
var counter2 = 0;
var counter3 = 0;
var searchString;
var totalhits =0;
var totalUnits=0;
var UnitDesc ='hit on Unit Content';
var LearningDec = "hit on Learning Outcome";
var AssessmentDec = "hit on Assessment";
var records;
var na ="";
var arraycounter =0;
var arrayIDHolder;

var Unit2UnitTitle = [];

const SDGgoals = ["Poverty", "Hunger","Good Health and Well-being","Quality Education","Gender Equality","Clean water and sanitation","Affordable and clean energy","Economic Growth","Industry, Innovation and Infrastructure","Reduced Inequalities","Sustainable cities and communities","Responsible consumption and production","Climate action","Life below water","Life on land","Peace, Justice and Strong institutions","Partnerships for goals"];


var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "1C+302$@l",
  database: "SDG"
//  password: "ICT302web",
//  database: "testSDG"
});

connection.connect();

//processing the option 2 and getting the user selected degree and than searching the csv storing them in an array and than searching and outputting it
function reqUploadTwo(request, response) {
//	const SDGgoals = ["Poverty", "Hunger","Good Health and Well-being","Quality Education","Gender Equality","Clean water and sanitation","Affordable and clean energy","Economic Growth","Industry, Innovation and Infrastructure","Reduced Inequalities","Sustainable cities and communities","Responsible consumption and production","Climate action","Life below water","Life on land","Peace, Justice and Strong institutions","Partnerships for goals"];

	truncateSDGTables();
//		UnitSearch(SDGgoals);
//		SearchLearningOutcome(SDGgoals);  // pushed to calling from each function as node js runs in parallel 
//		SearchAssessment(SDGgoals);
//				addUnitTitle2Array()
//	pushArray2Table();	

		//connection.end();
//		console.log("\n\n Total Units processed : " + totalUnits);
//		console.log("\n\n Total hits on all goals : " + Array.length);
		
		
				
}


function UnitSearch(SDGgoals){
	var Array2 =[];
	
	connection.query('SELECT Year, UnitCode,UnitTitle, Description, Content, LearningExperiences, Overview, OtherNotes from Unit', function (error,results, fields) {
		  if (error) throw error;	
		  
		  Unit2UnitTitle = results;
		  
		  console.log("\n\n The Unit Content \n\n");
			for(var a = 0; a < SDGgoals.length; a++){
				
				counter = 0;
				searchString = SDGgoals[a];
				
					//sdg goal appropriate set assigning
					if(searchString == "Poverty"){						
						searchGoal =  [/poverty/, /poor/];
			
					}else if(searchString == "Hunger"){
						searchGoal =  [/Hunger/, /scarcity/, /drought/, /starvation/];
						
					}else if(searchString == "Good Health and Well-being"){
						searchGoal =  [/Health/];
						
					}else if(searchString == "Quality Education"){
						searchGoal =  [/Education/, /studies/, /qualification/];
						  
					}else if(searchString == "Gender Equality"){
						searchGoal =  [/Gender/];
						
					}else if(searchString == "Clean water and sanitation"){
						searchGoal =  [/Clean Water/,/Water Sanitation/, /water/, /sanitation/];
						
					}else if(searchString == "Affordable and clean energy"){
						searchGoal =  [/Affordable Energy/, /Clean Energy/, /energy/];
						
					}else if(searchString == "Economic Growth"){
						searchGoal =  [/Decent Work/, /Economic Growth/, /economy/];
						
					}else if(searchString == "Industry, Innovation and Infrastructure"){
						searchGoal =  [/Industry/, /Innovation/, /Infrastructure/];
						
					}else if(searchString == "Reduced Inequalities"){
						searchGoal =  [/Reduced Inequality/,/inequality/ ];
						
					}else if(searchString == "Sustainable cities and communities"){
						searchGoal =  [/Sustainable Cities/, /Sustainable Communities/];
						
					}else if(searchString == "Responsible consumption and production"){
						searchGoal =  [/Consumption/,/Responsible Consumption/, /Responsible Production/,/Production/ ];
						
					}else if(searchString == "Climate action"){
						searchGoal =  [/Climate Action/, /climate/,/weather/];
						
					}else if(searchString == "Life below water"){
						searchGoal =  [/Life Below Water/, /life under water/, /life in water/ ];
						
					}else if(searchString == "Life on land"){
						searchGoal =  [/Life on Land/, /life above land/];
						
					}else if(searchString == "Peace, Justice and Strong institutions"){
						searchGoal =  [/Peace/, /Justice/, /Justice Strong Institutions/, /Justice Institution/];
						
					}else if(searchString == "Partnerships for goals"){ 
						searchGoal =  [/Partnership/,/Partnership Goal/];
						
					}
								
						for(var i =0; i < results.length; i++){
							
							for(var j =0; j < searchGoal.length; j++){
							
								if( (searchGoal[j].test(results[i].Description)) || (searchGoal[j].test(results[i].Content)) ||
								(searchGoal[j].test(results[i].LearningExperiences)) || (searchGoal[j].test(results[i].Overview))
								|| (searchGoal[j].test(results[i].OtherNotes)) )
								{
									arrayLineExistsUnit=false;
									arylength = Array.length
									if(arylength>0)
										{
										for(var chkindex = 0; chkindex <arylength;chkindex++)
											{

												if(Array[chkindex].Year == results[i].Year && Array[chkindex].UnitCode==results[i].UnitCode && Array[chkindex].SDG==searchString)

												{
														counter++; // counting hits
														 arrayLineExistsUnit=true;
												}  // end if chkindex
												
											} //end for chkindex
										} else
										{ // end if Array.length
									 // runs when first match made afterwards need to check if line already exists
									data ="";
									data = {ID:arraycounter, Year:results[i].Year, UnitCode:results[i].UnitCode,UnitTitle:results[i].UnitTitle,SDG:searchString,FlagUnit:UnitDesc,FlagLO:na, FlagAssessment:na};
									Array.push(data);
									counter++; //counting hits
									arraycounter++; //increment array ID for next line
									}
									if(!arrayLineExistsUnit) //if you dont find the line in the array add it to the array
										{
												data ="";
												data = {ID:arraycounter, Year:results[i].Year, UnitCode:results[i].UnitCode,UnitTitle:results[i].UnitTitle,SDG:searchString,FlagUnit:UnitDesc,FlagLO:na, FlagAssessment:na};
												Array.push(data);
												counter++; //counting hits
												arraycounter++; //increment array ID for next line
												}
												
								if(searchGoal[j].test(results[i].Description)){

									
									data2 = {UnitCode:results[i].UnitCode,UnitAreaFlag:"Description"};
									Array2.push(data2);
			
								}else if (searchGoal[j].test(results[i].Content)){
									
									data2 = {UnitCode:results[i].UnitCode,UnitAreaFlag:"Content"};
									Array2.push(data2);
									
								}else if (searchGoal[j].test(results[i].LearningExperiences)){
									
									data2 = {UnitCode:results[i].UnitCode,UnitAreaFlag:"LearningExperiences"};
									Array2.push(data2);
									
								}else if(searchGoal[j].test(results[i].Overview)) {
									
									data2 = {UnitCode:results[i].UnitCode,UnitAreaFlag:"Overview"};
									Array2.push(data2);
									
								}else if (searchGoal[j].test(results[i].OtherNotes)){
									
									data2 = {UnitCode:results[i].UnitCode,UnitAreaFlag:"OtherNotes"};
									Array2.push(data2);
									
								}
												
								}
							}
							
							totalUnits++;
						}
						totalhits += counter;
						console.log("Total UNITS by (" + searchString + ") : " + counter);	
					//	console.log("Total AssessmentS HITS by (" + searchString + ") : " + counter);
			
			
						var sql = "INSERT INTO Unit2SDG (Year, SDG, HitCount) VALUES ('" + results[1].Year + "','" + searchString + "','" + counter +"')";
				
						 connection.query(sql, function (err, result) {
							if (err) throw err;
							
						  });


			}


console.log("Array2 size   =  "+Array2.length);

for (Array2_i = 0;Array2_i < Array2.length;Array2_i++){

							var	sql2 = "INSERT INTO UnitFoundIn (UnitCode, Flag) VALUES ('" + Array2[Array2_i].UnitCode + "','" + Array2[Array2_i].UnitAreaFlag + "')";
								
								 connection.query(sql2, function (err, result) {
									if (err) throw err;
							//		console.log("1 record inserted");
									
								  });
					}


			
			console.log("\n\n Total hits on Units from goals : " + totalhits);
		
	});
		SearchLearningOutcome(SDGgoals);		
}

function SearchLearningOutcome(SDGgoals){
	
	//query for learningoutcome
	connection.query('SELECT Year, UnitCode, Description from LearningOutcome', function (error2,results2, fields2) {
			if (error2) throw error2;	

			console.log("\n\n The LearningOutcome\n\n");
			
		for(var b= 0; b < SDGgoals.length; b++){
					
					counter2 = 0;
					searchString = SDGgoals[b];
					
						//sdg goal appropriate set assigning
						if(searchString == "Poverty"){						
							searchGoal =  [/poverty/, /poor/];
				
						}else if(searchString == "Hunger"){
							searchGoal =  [/Hunger/, /scarcity/, /drought/, /starvation/];
							
						}else if(searchString == "Good Health and Well-being"){
							searchGoal =  [/Health/];
							
						}else if(searchString == "Quality Education"){
							searchGoal =  [/Education/, /studies/, /qualification/];
							  
						}else if(searchString == "Gender Equality"){
							searchGoal =  [/Gender/];
							
						}else if(searchString == "Clean water and sanitation"){
							searchGoal =  [/Clean Water/,/Water Sanitation/, /water/, /sanitation/];
							
						}else if(searchString == "Affordable and clean energy"){
							searchGoal =  [/Affordable Energy/, /Clean Energy/, /energy/];
							
						}else if(searchString == "Economic Growth"){
							searchGoal =  [/Decent Work/, /Economic Growth/, /economy/];
							
						}else if(searchString == "Industry, Innovation and Infrastructure"){
							searchGoal =  [/Industry/, /Innovation/, /Infrastructure/];
							
						}else if(searchString == "Reduced Inequalities"){
							searchGoal =  [/Reduced Inequality/,/inequality/ ];
							
						}else if(searchString == "Sustainable cities and communities"){
							searchGoal =  [/Sustainable Cities/, /Sustainable Communities/];
							
						}else if(searchString == "Responsible consumption and production"){
							searchGoal =  [/Consumption/,/Responsible Consumption/, /Responsible Production/,/Production/ ];
							
						}else if(searchString == "Climate action"){
							searchGoal =  [/Climate Action/, /climate/,/weather/];
							
						}else if(searchString == "Life below water"){
							searchGoal =  [/Life Below Water/, /life under water/, /life in water/ ];
							
						}else if(searchString == "Life on land"){
							searchGoal =  [/Life on Land/, /life above land/];
							
						}else if(searchString == "Peace, Justice and Strong institutions"){
							searchGoal =  [/Peace/, /Justice/, /Justice Strong Institutions/, /Justice Institution/];
							
						}else if(searchString == "Partnerships for goals"){ 
							searchGoal =  [/Partnership/,/Partnership Goal/];
							
						}
									
			
			for(var k =0; k < results2.length; k++){
				
				for(var l =0; l < searchGoal.length; l++){
				
					if(searchGoal[l].test(results2[k].Description))
					{
						
						// check if array line exists with UnitCode or LEARNINGOUTCOME
						arrayLineExistsUnit=false;
						arrayLineExistsLO=false;
								//	console.log("aryleng = "+Array.length);
									arylength = Array.length
									if(arylength>0)
										{
										for(var chkLOindex = 0; chkLOindex <arylength;chkLOindex++)
											{
									
						//if(Array[chkLOindex].Year == results[i].Year && Array[chkindex].UnitCode==results[i].UnitCode && Array[chkindex].SDG==searchString)
						if(Array[chkLOindex].Year == results2[k].Year && Array[chkLOindex].UnitCode == results2[k].UnitCode && Array[chkLOindex].SDG == searchString)
//							&& Array[chkLOindex].FlagUnit == UnitDesc)
						{
							if(Array[chkLOindex].FlagUnit == UnitDesc)
							{
							arrayLineExistsUnit=true;
//							arrayIDHolder = Array[chkLOindex].ID;
							Array[chkLOindex].FlagLO = LearningDec;  // if UnitFlag exists set LOFlag on same ArrayID
//							console.log("UnitFLag " +arrayIDHolder+Array[chkLOindex].UnitCode);
							//counter2++;
							}

							// check if array line exists with no UnitCode but LearningOutcome 
							if(Array[chkLOindex].FlagLO == LearningDec)
							{
								arrayLineExistsLO = true;
//								arrayIDHolder = Array[chkLOindex].ID;
//								console.log("LO  FLag " +arrayIDHolder+Array[chkLOindex].UnitCode);
							} //end if array line exists with no UnitCode but LearningOutcome
						
						} //end for chkLOindex
				} //end if arylength
									data ="";

									if(!(arrayLineExistsUnit||arrayLineExistsLO))  // if neither Unit of LO found add new line to aray
									{

										data = {ID:arraycounter,Year:results2[k].Year, UnitCode:results2[k].UnitCode,UnitTitle:na,SDG:searchString,FlagUnit:na,FlagLO:LearningDec,FlagAssessment:na};
										Array.push(data);
										counter2++; //counting the hits
										arraycounter++; // //increment array ID for next line
//										console.log(data);
									}
									else // if old array index updated increment counter
									{
										counter2++;
									}
									

										}  //end if array length
			}  //end if searchGoal search success
				
				
				
		} // end for searchgoal (l) 

			}// end for results (k)
		console.log("Total LEARNINGOUTCOME HITS by (" + searchString + ") : " + counter2);
		} // for SDG Goals (b)
				totalhits += counter2;
	//			console.log("Total LEARNINGOUTCOME HITS by (" + searchString + ") : " + counter2);
	
		console.log("\n\n Total hits on Learning outcomes goals : " + totalhits);
	//totalhits =0;
	
	});		

		SearchAssessment(SDGgoals);

}

function SearchAssessment(SDGgoals){
	
	//query for Assessment
	connection.query('SELECT Year, UnitCode,DemonstratesGraduateAttributes, Description from Assessment', function (error3,results3, fields3) {
			if (error3) throw error3;	


			console.log("\n\n The Assessment\n\n");
		for(var c = 0; c < SDGgoals.length; c++){
					
					counter3 = 0;
					searchString = SDGgoals[c];
					
						//sdg goal appropriate set assigning
						if(searchString == "Poverty"){						
							searchGoal =  [/poverty/, /poor/];
				
						}else if(searchString == "Hunger"){
							searchGoal =  [/Hunger/, /scarcity/, /drought/, /starvation/];
							
						}else if(searchString == "Good Health and Well-being"){
							searchGoal =  [/Health/, /lifestyle/];
							
						}else if(searchString == "Quality Education"){
							searchGoal =  [/Education/, /studies/, /qualification/];
							  
						}else if(searchString == "Gender Equality"){
							searchGoal =  [/Gender/,/sex/,/racisum/];
							
						}else if(searchString == "Clean water and sanitation"){
							searchGoal =  [/Clean Water/,/Water Sanitation/, /water/, /sanitation/];
							
						}else if(searchString == "Affordable and clean energy"){
							searchGoal =  [/Affordable Energy/, /Clean Energy/, /energy/];
							
						}else if(searchString == "Economic Growth"){
							searchGoal =  [/Decent Work/, /Economic Growth/, /economy/];
							
						}else if(searchString == "Industry, Innovation and Infrastructure"){
							searchGoal =  [/Industry/, /Innovation/, /Infrastructure/];
							
						}else if(searchString == "Reduced Inequalities"){
							searchGoal =  [/Reduced Inequality/,/inequality/ ];
							
						}else if(searchString == "Sustainable cities and communities"){
							searchGoal =  [/Sustainable Cities/, /Sustainable Communities/];
							
						}else if(searchString == "Responsible consumption and production"){
							searchGoal =  [/Consumption/,/Responsible Consumption/, /Responsible Production/,/Production/ ];
							
						}else if(searchString == "Climate action"){
							searchGoal =  [/Climate Action/, /climate/,/weather/];
							
						}else if(searchString == "Life below water"){
							searchGoal =  [/Life Below Water/, /life under water/, /life in water/ ];
							
						}else if(searchString == "Life on land"){
							searchGoal =  [/Life on Land/, /life above land/];
							
						}else if(searchString == "Peace, Justice and Strong institutions"){
							searchGoal =  [/Peace/, /Justice/, /Justice Strong Institutions/, /Justice Institution/];
							
						}else if(searchString == "Partnerships for goals"){ 
							searchGoal =  [/Partnership/,/Partnership Goal/];
							
						}
									
			
			for(var m =0; m < results3.length; m++){
				
				for(var n =0; n < searchGoal.length; n++){
				
					if( (searchGoal[n].test(results3[m].DemonstratesGraduateAttributes)) || 
					(searchGoal[n].test(results3[m].Description)) ) 
					{
						
						// check if array line exists with UnitCode or LEARNINGOUTCOME
						arrayLineExistsUnit=false;
						arrayLineExistsLO=false;
						arrayLineExistsAssessment=false;
						
								//	console.log("aryleng = "+Array.length);
									arylength = Array.length
									if(arylength>0)
										{
										for(var chkAssessmentindex = 0; chkAssessmentindex <arylength;chkAssessmentindex++)
											{
									
						if(Array[chkAssessmentindex].Year == results3[m].Year && Array[chkAssessmentindex].UnitCode == results3[m].UnitCode && Array[chkAssessmentindex].SDG == searchString)

						{
							// check if array line exists with UnitFlag
							if(Array[chkAssessmentindex].FlagUnit == UnitDesc)
							{
							arrayLineExistsUnit=true;
							Array[chkAssessmentindex].FlagAssessment = AssessmentDec;  // if UnitFlag exists set AssessmentFlag on same ArrayID

							} //end if array line exists Unit 

							// check if array line exists with LearningOutcome Flag
							if(Array[chkAssessmentindex].FlagLO == LearningDec)
							{
								arrayLineExistsLO = true;
								Array[chkAssessmentindex].FlagAssessment = AssessmentDec;  // if LOFlag exists set AssessmentFlag on same ArrayID

							} //end if array line exists LearningOutcome
							
							// check if array line exists with Assessment Flag
							if(Array[chkAssessmentindex].FlagAssessment == AssessmentDec)
							{
								arrayLineExistsAssessment = true;

							} //end if array line exists Assessment
						
						} //end for chkAssessmentindex
				} //end if arylength
									data ="";

									if(!(arrayLineExistsUnit||arrayLineExistsLO||arrayLineExistsAssessment))  // if none of Unit of LO or Assessment found add new line to array
									{

										data = {ID:arraycounter,Year:results3[m].Year, UnitCode:results3[m].UnitCode,UnitTitle:na,SDG:searchString,FlagUnit:na,FlagLO:na,FlagAssessment:AssessmentDec};
										Array.push(data);
										counter3++; //counting the hits
										arraycounter++; // //increment array ID for next line
									}
									else // if old array index updated increment counter
									{
										counter3++;
									}
									

										}  //end if array length	

					}
				}
			}
			
			totalhits += counter3;
			console.log("Total Assessment HITS by (" + searchString + ") : " + counter3);
			

		}	
		
		console.log("\n\n Total hits on all goals : " + totalhits);
		pushArray2Table();	
//		addUnitTitle2Array();
	});	
		
}


function addUnitTitle2Array(){
	
	for (var UnitTitleIndex = 0; UnitTitleIndex < Array.length; UnitTitleIndex++)
	{
		for (var UnitTableIndex = 0; UnitTableIndex< Unit2UnitTitle.length;UnitTableIndex++)
		{
			if(Array[UnitTitleIndex].UnitCode == Unit2UnitTitle[UnitTableIndex].UnitCode)
			{
//				console.log("Array   UnitCode "+Array[UnitTitleIndex].UnitCode);
//				console.log("results UnitCode "+Unit2UnitTitle[UnitTableIndex].UnitCode);
				Array[UnitTitleIndex].UnitTitle = Unit2UnitTitle[UnitTableIndex].UnitTitle;
//				console.log("Array   UnitTitle "+Array[UnitTitleIndex].UnitTitle);
//				console.log("results UnitTitle "+Unit2UnitTitle[UnitTableIndex].UnitTitle);				
			}	
		}
		
		 
	}
	
//	pushArray2Table();	
}



function pushArray2Table(){
	var sql;
	var data;
///console.log(Array);
	for(var i = 0; i< Array.length; i++){
     // //console.log("debug Unit" + Array[i].FlagUnit +" LO "+Array[i].FlagLO+" Assess "+Array[i].AssessmentDec);
//console.log("i= "+i,Array[i].ID,Array[i].Year,Array[i].UnitCode,Array[i].SDG,Array[i].FlagUnit,Array[i].FlagLO,Array[i].FlagAssessment);
			dataArray="";
			dataArray = [[Array[i].FlagUnit,Array[i].FlagLO,Array[i].FlagAssessment]];
//			sql = "INSERT INTO SDGHitDesc (Year,UnitCode,UnitTitle, SDG, HiTFlagedIn) VALUES ('" + Array[i].Year + "','" + Array[i].UnitCode + "','"+ Array[i].UnitTitle + "','" + Array[i].SDG + "','" + dataArray +"')";
			sql = "INSERT INTO SDGHitDesc (Year,UnitCode, SDG, HiTFlagedIn) VALUES ('" + Array[i].Year + "','" + Array[i].UnitCode + "','" +Array[i].SDG + "','" + dataArray +"')";
//console.log(sql);			
			 connection.query(sql, function (err, result) {
				if (err) throw err;
				//console.log("1 record inserted");
				
			  });
	}
// connection.end();	
countUnit2SDGHit();
//addUnitTitle2SDGHitDesc();
}




function countUnit2SDGHit()
{
	// https://arstechnica.com/civis/viewtopic.php?t=804490  read comments about newbie v junior pro v pro
/*
	sql = `UPDATE SDG.SDGHitDesc,SDG.Unit2SDG
		set Unit2SDG.HitCount = select count (*) from SDGHitDesc where SDGHitDesc.SDG = Unit2SDG.SDG`;
*/
		sql = `CREATE TEMPORARY TABLE unit2sdgcount
				SELECT  SDG, count(*) AS mycount from SDGHitDesc GROUP BY SDG`;
/*
		UPDATE SDG.SDGHitDesc,SDG.unit2sdgcount, Unit2SDG
		set Unit2SDG.HitCount = mycount where SDGHitDesc.SDG = unit2sdgcount.SDG`;	
*/		
		
					 connection.query(sql, function (err, result) {
				if (err) throw err;
//				console.log("unit2sdgcount Updated");
				
			  });
			  
			  			sql = `UPDATE SDG.unit2sdgcount,SDG.Unit2SDG
		set Unit2SDG.HitCount = unit2sdgcount.mycount where Unit2SDG.SDG = unit2sdgcount.SDG`;	
		
		
					 connection.query(sql, function (err, result) {
				if (err) throw err;
				console.log("Unit2SDG Updated");
				
			  });

addUnitTitle2SDGHitDesc();			  
//connection.end();
}



function addUnitTitle2SDGHitDesc()
{
	// https://arstechnica.com/civis/viewtopic.php?t=804490  read comments about newbie v junior pro v pro
	sql = `UPDATE SDG.SDGHitDesc,SDG.Unit
		set SDGHitDesc.UnitTitle = Unit.UnitTitle
		where SDGHitDesc.UnitCode = Unit.UnitCode`;
		
					 connection.query(sql, function (err, result) {
				if (err) throw err;
				console.log("Unit Title UPdates");
				
			  });
connection.end();
}

function truncateSDGTables()
{
	// https://arstechnica.com/civis/viewtopic.php?t=804490  read comments about newbie v junior pro v pro

	sql = "TRUNCATE table SDG.Unit2SDG";
//	TRUNCATE table testSDG.SDGHitDesc;";
		
					 connection.query(sql, function (err, result) {
				if (err) throw err;
				console.log("Truncate Unit2SDG");
				
			  });

			  	sql = "TRUNCATE table SDG.SDGHitDesc";
//	TRUNCATE table testSDG.SDGHitDesc;";
		
					 connection.query(sql, function (err, result) {
				if (err) throw err;
				console.log("Truncate SDGHitDesc");
				
			  });
			  
			  	sql = "TRUNCATE table SDG.UnitFoundIn";
//	TRUNCATE table SDG.UnitFoundIn;";
		
					 connection.query(sql, function (err, result) {
				if (err) throw err;
				console.log("Truncate UnitFoundIn");
				
			  });
			  
//connection.end();
		UnitSearch(SDGgoals);
}




//handler for Ajax file
function pageHashing(request, response) {	

	response.writeHead(200,{'Content-Type': 'text/script'}); 
	var javascript = fs.createReadStream('./ajaxPageswitch.js');
    javascript.pipe(response); 

}

//handler for html file
function showHomePage(request, response) {	

	response.writeHead(200,{'Content-Type': 'text/html'}); 
	var homePage = fs.createReadStream('../index.html');
    homePage.pipe(response);

}

//handler for stylesheet
function styleSheet(request, response) {	

	response.writeHead(200,{'Content-Type': 'text/css'}); 
	var homePage = fs.createReadStream('../css/stylesheet.css');
    homePage.pipe(response);

}

//exporting the function to allow the handler to match appropriately
exports.showHomePage = showHomePage;
exports.pageHashing = pageHashing;
exports.styleSheet = styleSheet;
 
exports.reqUploadTwo = reqUploadTwo;
