/*This file is used to route all the data and process and send it to appropriate handler */
function route(handle, pathname, request, response) {
	
	//checking if the handler is presnt or not to handel the request
	if (typeof handle[pathname] === 'function') {
		
		//passing the data to appropriate handler
		handle[pathname](request, response);
	
	} else { 

		//if the handler is not available this is printed to notify the client
		response.writeHead(404, {"Content-Type": "text/plain"});
		response.write("Resource not found!");
		response.end();

	}
	  
}
//exporting to make this function available to the other files for using it
exports.route = route;  