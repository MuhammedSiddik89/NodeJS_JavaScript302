//appropriate modules are assigned
var http = require("http");
var url = require("url");
 
/* This function is the server and passing ther requested infromation to the router */ 
function startServer(route, handle) {
	
	//All the information processed are to be passed in and out through server -> router 
	function onRequest(request, response) {
		
		//getting the path name by breaking the url into parts using aprse
		var pathname = url.parse(request.url).pathname;
	
		//forwarding the request to the router 
		route(handle, pathname, request, response);

	}
	
		//Creating server conncetion using the relevent port number  
		http.createServer(onRequest).listen(8080);
		console.log("Server has started...");
}  

//exporting the function to make it available to other files to use it
exports.startServer = startServer;
