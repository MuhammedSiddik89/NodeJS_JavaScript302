//all the hashing pages section are stored in the array
var pages = ["#option1", "#studentTable"];

//the first page from array is to be loaded in default and assigned as current page
var curPage = pages[0];

//page hashing taken from ICT286 lab 
$(document).ready(function(){

	//page hashing is being used
   var newPage = getPage(window.location.hash);
   render(newPage);

	//rendering the new page
	$(window).on('hashchange', function(){
			
			var newPage = getPage(window.location.hash);
	   
			render(newPage);
	});
   
  
   //checking if the page is required to be swaped or not
	function render(newPage){
		
		if (newPage == curPage) return;

		$(curPage).hide();
		$(newPage).show();
		curPage = newPage; 
	}

	//getting the page hash from the above pages array
	function getPage(hash){

		var i = pages.indexOf(window.location.hash);
		
		return i < 1 ? pages[0] : pages[i];
	}

	//this is used to get the search result and presenting the response from the handler
    $('#sdgSearchForm').on('submit', function(e)
    {
		//preventing page refresh
		e.preventDefault();
	    window.location.hash=pages[1]; //hardcoded page from the aray as its not in the naviagtion list
	   
		//ajax request for getting the search result from the handler
		$.ajax(
	    {			
			data: $('#sdgSearchForm').serialize(), //getting the data
		    type: 'POST',
			url: '/upload2', //handler in place of url user
			
			//error handling and printing appropriate response to the end user
		    success:function(response)
		    {
				//$('#option1').hide();
			    $('#studentTable').html(response);
				
		    },
		    error:function(response)
		    {
				alert("Search Failed");
		    }
	    })
    })
   
   
   
      
});