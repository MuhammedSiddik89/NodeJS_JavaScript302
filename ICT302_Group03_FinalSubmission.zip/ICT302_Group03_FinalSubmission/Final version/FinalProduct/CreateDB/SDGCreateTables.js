

// https://www.wikitechy.com/tutorials/node-js/node-js-mysql-create-database
//ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password'

// CREATE TABLES
// CONNECT testSDG DB
var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "1C+302$@l",
  database: "SDG"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected! Table Creation");

// CREATE TABLES
  var sql = "CREATE TABLE Unit (id INT AUTO_INCREMENT PRIMARY KEY, Year INT, UnitCode VARCHAR(30), UnitTitle VARCHAR(100),CreditPoints INT, School_parent_academic_org VARCHAR(100),Discipline_academic_org VARCHAR(100),BroadFieldofEducation VARCHAR(100),NarrowFieldofEducation VARCHAR(100),FieldofEducation VARCHAR(100),Description TEXT,Content TEXT,LearningExperiences TEXT,Overview TEXT,OtherNotes TEXT)";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table Unit created");
  });
  var sql = "CREATE TABLE Assessment (id INT AUTO_INCREMENT PRIMARY KEY, Year INT, UnitCode VARCHAR(30), AssessmentType VARCHAR(100),Weight INT,Due VARCHAR(100),AssessmentName VARCHAR(100),DemonstratesGraduateAttributes TEXT,Description  TEXT,Individual TEXT,Supervised TEXT,AssessmentCategory TEXT,LearningOutcomes TEXT)";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table Assessment created");
  });
  var sql = "CREATE TABLE LearningOutcome (id INT AUTO_INCREMENT PRIMARY KEY, Year INT, UnitCode VARCHAR(30), OutcomeCode VARCHAR(100),Description TEXT)";
  
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table LearningOutcome created");
  });
  var sql = "CREATE TABLE Assessment2SDGMapping (id INT AUTO_INCREMENT PRIMARY KEY, Year INT, UnitCode VARCHAR(30), AssessmentType VARCHAR(100),SDG TEXT, HitCount INT)";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table Assessment2SDGMapping created");
  });
  var sql = "CREATE TABLE Unit2SDGMapping (id INT AUTO_INCREMENT PRIMARY KEY, Year INT, UnitCode VARCHAR(30),SDG TEXT, HitCount INT)";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table Unit2SDGMapping created");
  });
  con.end();
  
});

