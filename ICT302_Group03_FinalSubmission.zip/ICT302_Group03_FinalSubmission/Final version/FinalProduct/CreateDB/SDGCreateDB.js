
// https://www.wikitechy.com/tutorials/node-js/node-js-mysql-create-database
//ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password'

// CREATE MYSQL DB
// CONNECT MYSQL
var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "1C+302$@l"
});

// CREATE MYSQL DB
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected! DB Creation");
  con.query("CREATE DATABASE SDG", function (err, result) {
    if (err) throw err;
    console.log("Database created"); 
  });  
  con.end();
});
