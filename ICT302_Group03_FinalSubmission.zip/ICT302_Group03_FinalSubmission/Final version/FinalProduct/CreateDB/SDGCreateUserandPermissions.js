

// https://www.wikitechy.com/tutorials/node-js/node-js-mysql-create-database
//ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password'

// CREATE USER AND ADD PERMISSIONS
// CONNECT MYSQL
var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "1C+302$@l",
  database: "SDG"
});

// CREATE USER AND ADD PERMISSIONS
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected! User Creation");
  // create webapp user
  con.query("CREATE USER 'webapp'@'localhost' IDENTIFIED BY '1C+302r3@d'", function (err, result) {
    if (err) throw err;
    console.log("webapp user created");
  });

  // grant permission to webapp user
  con.query("GRANT SELECT ON SDG.* TO webapp@localhost", function (err, result) {
    if (err) throw err;
    console.log("SELECT permission added to webapp");
  });

  con.end();
});
