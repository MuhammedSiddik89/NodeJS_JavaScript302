<?php
    $con = mysqli_connect("localhost", "root", "", "local_DB");

    if (mysqli_connect_errno())
    {
        echo'connect fail';
        die(); //Kill the script so the user can't peek at any errors our code may produce.
        //mysqli_connect_error();
    }

?>
