<?php
	require "./Header.php";
?>
                    <div class="widget_container_UN">
                        <div class="content_box_UN">
                            <div class="col-md-9">
                                <h1 class="index_heading">SUSTAINABLE DEVELOPMENT GOALS </h1>
                                <h2>The 17 Sustainable Development Goals (SDGs) are the world’s best plan to build a better world for people and our planet by 2030. ~ United Nations</h2>
                            </div>
                            <!--	/* <div class="col-xs-3">
			//<img alt="UN sustainable image" src="img/unlight.svg"/>
		</div> */ -->
                        </div>
                    </div>
                    <div class="widget_container_2">
                        <div class="content_box_2">
                            <div class="col-md-7">
                                <h1>Information About The UN Goals</h1>
                                <br />
                                <p>The SDGs are a call for action by all countries – poor, rich and middle-income – to promote prosperity while protecting the environment. They recognize that ending poverty must go hand-in-hand with strategies that
                                    build economic growth and address a range of social needs including education, health, equality and job opportunities, while tackling climate change and working to preserve our ocean and forests. ~ United Nations
                                </p>
                            </div>
                            <div class="col-md-4">
                                <h2>How Can you Help ? </h2>
                                <p>"That's one small step for (a) man, one giant leap for mankind". <br /> ~Neil Armstrong. </p>
                                <p> <a href="https://www.murdoch.edu.au/contact-us" /> Contact us to find out more. </a>
                            </div>
                        </div>
                    </div>
                    <div class="accordion_box">
                        <ul class="demo hide_me">
                            <li class="first">
                                <h3>Energy Goals</h3>
                                <br />
                                <div class="subtitle hidden">
                                    <h2>Energy is predominantly central to almost every major challenge or opportunity. </h2>
                                    <br />
                                    <br />
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color:#CC7722;">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-07.svg" />
                                                <div class="un_goal_menu">

                                                </div>
                                            </div>
                                            <span>Goal 7</span>
                                            <p>Affordable & Clean Energy</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <a href="map.html">Action</a>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ace.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/goal-07/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ace.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color:#F89D2A;">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-11.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 11</span>
                                            <p>Sustainable Cities & Communities</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/scc.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://www.un.org/sustainabledevelopment/cities/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/scc.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="second">
                                <h3>EcoSystem Goals</h3>
                                <br />
                                <div class="subtitle hidden">
                                    <h2>
                                        "The EcoSystem adjusts itself and for every action there is a reaction". <br />
                                        <p> ~Steve Mills.
                                    </h2>
                                    </p>
                                    <br />
                                    <br />
                                    <div class="col-xs-4">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #F26A2E">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-09.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 9 </span>
                                            <p>Industry, Innovation & Infrastructure</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/iii.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/goal-09/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/iii.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-4">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #BF8D2C">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-12.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 12 </span>
                                            <p>Responsible Production & Consumption</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/goal=5F12.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-12/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/goal=5F12.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-4">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #407F46">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-13.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 13 </span>
                                            <p>Climate Action</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/goal=5F13.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-13/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/goal=5F13.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-4">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #1F97D4">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-14.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 14</span>
                                            <p>Life Below Water</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/marine.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-14/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/marine.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="seperator"></div>
                                    <div class="col-xs-4">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #59BA47">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-15.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 15 </span>
                                            <p>Life On Land</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/land.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-15/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/land.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="third">
                                <h3>Basic Human Rights Goals</h3>
                                <br />
                                <div class="subtitle hidden">
                                    <h2>
                                        "Human rights are something you were born with. Human rights are your God-given rights. Human rights are the rights recognised by all nations of this earth".<br />
                                        <p> ~Malcom X
                                    </h2>
                                    </p>
                                    <br />
                                    <br />
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color:#E5233D">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-01.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 1</span>
                                            <p>No Poverty</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/pov.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-01/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/pov.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #DDA73A">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-02.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 2</span>
                                            <p>Zero Hunger</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/hfs.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-02/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/hfs.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #4CA146">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-03.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 3</span>
                                            <p>Good Health & Wellbeing</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ghwb.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-03/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ghwb.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #C7212F">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-04.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 4</span>
                                            <p>Quality Education</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/qedu.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-04/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/qedu.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #EF402D">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-05.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 5</span>
                                            <p>Gender Equality</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ge.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-05/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ge.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="seperator"></div>
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #0095b6">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-06.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 6</span>
                                            <p>Clean Water & Sanitation</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/CWS.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-06/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/CWS.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #A31C44">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-08.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 8</span>
                                            <p>Decent Work & Economic Growth</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/dweg.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-08/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/dweg.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #DE1768">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-10.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 10</span>
                                            <p>Reduced Inequalities</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ri.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-10/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ri.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #136A9F">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-16.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 16</span>
                                            <p>Peace, Justice & Strong Institutions</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/pjsi.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-16/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/pjsi.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-3">
                                        <div class="UNlink">
                                            <div class="ungoal" style="background-color: #14496B">
                                                <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-17.svg" />
                                                <div class="un_goal_menu">
                                                </div>
                                            </div>
                                            <span>Goal 17</span>
                                            <p>Partnerships for the Goals</p>
                                            <div class="hiddenLinkAction" style="display:none;">
                                                <span>Action</span>
                                            </div>
                                            <div class="hiddenLinkCurriculum" style="display:none;">
                                                <a href="curriculum.php">Curriculum</a>
                                            </div>
                                            <div class="hiddenLinkResearch" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/gsd.html">Research</a>
                                            </div>
                                            <div class="hiddenLinkNews" style="display:none;">
                                                <a href="https://unstats.un.org/sdgs/report/2016/Goal-17/">News</a>
                                            </div>
                                            <div class="hiddenLinkRsrc" style="display:none;">
                                                <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/gsd.html">External Resources</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div id="UNpopUp">
                        <div id="Action" class="Action">
                            <a href="#">Action</a>
                        </div>
                        <div id="Curriculum" class="Action">
                            <a href="#">Curriculum</a>
                        </div>
                        <div id="Research" class="Action">
                            <a href="#">Research</a>
                        </div>
                        <div id="News" class="Action">
                            <a href="#">News</a>
                        </div>
                        <div id="ExternalResources" class="Action">
                            <a href="#">External Resources</a>
                        </div>
                    </div>

                    <div class="ResizeHidden">
                        <!--Accordion1-->
                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color:#CC7722;">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-07.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 7</span>
                                <p>Affordable & Clean Energy</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <a href="map.html">Action</a>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ace.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://unstats.un.org/sdgs/report/2016/goal-07/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ace.html">External Resources</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color:#F89D2A;">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-11.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 11</span>
                                <p>Sustainable Cities & Communities</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <span>Action</span>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/scc.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://www.un.org/sustainabledevelopment/cities/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/scc.html">External Resources</a>
                                </div>
                            </div>
                        </div>
                        <!--Accordion2-->
                        <div class="resizeWrap">

                            <div class="col-xs-4">
                                <div class="UNlink">
                                    <div class="ungoal" style="background-color: #F26A2E">
                                        <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-09.svg" />
                                        <div class="un_goal_menu">
                                        </div>
                                    </div>
                                    <span>Goal 9 </span>
                                    <p>Industry, Innovation & Infrastructure</p>
                                    <div class="hiddenLinkAction" style="display:none;">
                                        <span>Action</span>
                                    </div>
                                    <div class="hiddenLinkCurriculum" style="display:none;">
                                        <a href="curriculum.php">Curriculum</a>
                                    </div>
                                    <div class="hiddenLinkResearch" style="display:none;">
                                        <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/iii.html">Research</a>
                                    </div>
                                    <div class="hiddenLinkNews" style="display:none;">
                                        <a href="https://unstats.un.org/sdgs/report/2016/goal-09/">News</a>
                                    </div>
                                    <div class="hiddenLinkRsrc" style="display:none;">
                                        <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/iii.html">External Resources</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="UNlink">
                                    <div class="ungoal" style="background-color: #BF8D2C">
                                        <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-12.svg" />
                                        <div class="un_goal_menu">
                                        </div>
                                    </div>
                                    <span>Goal 12 </span>
                                    <p>Responsible Production & Consumption</p>
                                    <div class="hiddenLinkAction" style="display:none;">
                                        <span>Action</span>
                                    </div>
                                    <div class="hiddenLinkCurriculum" style="display:none;">
                                        <a href="curriculum.php">Curriculum</a>
                                    </div>
                                    <div class="hiddenLinkResearch" style="display:none;">
                                        <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/goal=5F12.html">Research</a>
                                    </div>
                                    <div class="hiddenLinkNews" style="display:none;">
                                        <a href="https://unstats.un.org/sdgs/report/2016/Goal-12/">News</a>
                                    </div>
                                    <div class="hiddenLinkRsrc" style="display:none;">
                                        <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/goal=5F12.html">External Resources</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="UNlink">
                                    <div class="ungoal" style="background-color: #407F46">
                                        <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-13.svg" />
                                        <div class="un_goal_menu">
                                        </div>
                                    </div>
                                    <span>Goal 13 </span>
                                    <p>Climate Action</p>
                                    <div class="hiddenLinkAction" style="display:none;">
                                        <span>Action</span>
                                    </div>
                                    <div class="hiddenLinkCurriculum" style="display:none;">
                                        <a href="curriculum.php">Curriculum</a>
                                    </div>
                                    <div class="hiddenLinkResearch" style="display:none;">
                                        <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/goal=5F13.html">Research</a>
                                    </div>
                                    <div class="hiddenLinkNews" style="display:none;">
                                        <a href="https://unstats.un.org/sdgs/report/2016/Goal-13/">News</a>
                                    </div>
                                    <div class="hiddenLinkRsrc" style="display:none;">
                                        <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/goal=5F13.html">External Resources</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-4">
                                <div class="UNlink">
                                    <div class="ungoal" style="background-color: #1F97D4">
                                        <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-14.svg" />
                                        <div class="un_goal_menu">
                                        </div>
                                    </div>
                                    <span>Goal 14</span>
                                    <p>Life Below Water</p>
                                    <div class="hiddenLinkAction" style="display:none;">
                                        <span>Action</span>
                                    </div>
                                    <div class="hiddenLinkCurriculum" style="display:none;">
                                        <a href="curriculum.php">Curriculum</a>
                                    </div>
                                    <div class="hiddenLinkResearch" style="display:none;">
                                        <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/marine.html">Research</a>
                                    </div>
                                    <div class="hiddenLinkNews" style="display:none;">
                                        <a href="https://unstats.un.org/sdgs/report/2016/Goal-14/">News</a>
                                    </div>
                                    <div class="hiddenLinkRsrc" style="display:none;">
                                        <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/marine.html">External Resources</a>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-4">
                                <div class="UNlink">
                                    <div class="ungoal" style="background-color: #59BA47">
                                        <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-15.svg" />
                                        <div class="un_goal_menu">
                                        </div>
                                    </div>
                                    <span>Goal 15 </span>
                                    <p>Life On Land</p>
                                    <div class="hiddenLinkAction" style="display:none;">
                                        <span>Action</span>
                                    </div>
                                    <div class="hiddenLinkCurriculum" style="display:none;">
                                        <a href="curriculum.php">Curriculum</a>
                                    </div>
                                    <div class="hiddenLinkResearch" style="display:none;">
                                        <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/land.html">Research</a>
                                    </div>
                                    <div class="hiddenLinkNews" style="display:none;">
                                        <a href="https://unstats.un.org/sdgs/report/2016/Goal-15/">News</a>
                                    </div>
                                    <div class="hiddenLinkRsrc" style="display:none;">
                                        <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/land.html">External Resources</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Accordion3-->
                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color:#E5233D">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-01.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 1</span>
                                <p>No Poverty</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <span>Action</span>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/pov.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://unstats.un.org/sdgs/report/2016/Goal-01/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/pov.html">External Resources</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color: #DDA73A">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-02.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 2</span>
                                <p>Zero Hunger</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <span>Action</span>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/hfs.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://unstats.un.org/sdgs/report/2016/Goal-02/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/hfs.html">External Resources</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color: #4CA146">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-03.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 3</span>
                                <p>Good Health & Wellbeing</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <span>Action</span>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ghwb.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://unstats.un.org/sdgs/report/2016/Goal-03/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ghwb.html">External Resources</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color: #C7212F">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-04.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 4</span>
                                <p>Quality Education</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <span>Action</span>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/qedu.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://unstats.un.org/sdgs/report/2016/Goal-04/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/qedu.html">External Resources</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color: #EF402D">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-05.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 5</span>
                                <p>Gender Equality</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <span>Action</span>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ge.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://unstats.un.org/sdgs/report/2016/Goal-05/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ge.html">External Resources</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color: #0095b6">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-06.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 6</span>
                                <p>Clean Water & Sanitation</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <span>Action</span>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/CWS.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://unstats.un.org/sdgs/report/2016/Goal-06/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/CWS.html">External Resources</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color: #A31C44">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-08.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 8</span>
                                <p>Decent Work & Economic Growth</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <span>Action</span>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/dweg.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://unstats.un.org/sdgs/report/2016/Goal-08/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/dweg.html">External Resources</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color: #DE1768">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-10.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 10</span>
                                <p>Reduced Inequalities</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <span>Action</span>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ri.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://unstats.un.org/sdgs/report/2016/Goal-10/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/ri.html">External Resources</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color: #136A9F">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-16.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 16</span>
                                <p>Peace, Justice & Strong Institutions</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <span>Action</span>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/pjsi.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://unstats.un.org/sdgs/report/2016/Goal-16/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/pjsi.html">External Resources</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="UNlink">
                                <div class="ungoal" style="background-color: #14496B">
                                    <img class="w_h_100" src="img/SDGIcon/E_SDG_Icons-17.svg" />
                                    <div class="un_goal_menu">
                                    </div>
                                </div>
                                <span>Goal 17</span>
                                <p>Partnerships for the Goals</p>
                                <div class="hiddenLinkAction" style="display:none;">
                                    <span>Action</span>
                                </div>
                                <div class="hiddenLinkCurriculum" style="display:none;">
                                    <a href="curriculum.php">Curriculum</a>
                                </div>
                                <div class="hiddenLinkResearch" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/gsd.html">Research</a>
                                </div>
                                <div class="hiddenLinkNews" style="display:none;">
                                    <a href="https://unstats.un.org/sdgs/report/2016/Goal-17/">News</a>
                                </div>
                                <div class="hiddenLinkRsrc" style="display:none;">
                                    <a href="http://researchrepository.murdoch.edu.au/view/un_dev_goals/gsd.html">External Resources</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End.hidden-->


                <!-- dark overlay when nav opens -->



       
              <?php
                require "./Footer.php";
              ?>

