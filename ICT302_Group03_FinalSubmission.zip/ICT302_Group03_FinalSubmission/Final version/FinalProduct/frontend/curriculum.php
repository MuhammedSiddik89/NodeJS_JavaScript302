<?php
	require "./Header_curriculum.php";
?>
                <!-- Visualisation code below -->
			
			<br /><br /><br /><br /><br /><br /><br />
			<nav id="nav">
				<ul>
					<li id="a" class="left"><a href="#c0">Polar Area</a></li>
					<li id="b" class="left"><a href="#c1">Pie</a></li>
					<li id="c" class="left"><a href="#c2">Radar</a></li>
					<li id="d" class="left"><a href="#c3">Line</a></li>
					<li id="e" class="left"><a href="#c4">Bar</a></li>
					<li id="f" class="right">
  						<form action="/unit.php" method="get">
  							<input type="text" name="unit" placeholder="Search Unit (eg. ICT302)" id="unitsearch" required>
  							<button type="submit" class="searchButton">Search</button>
  						</form>
  					</li>
					<li id="g" class="left"><a href = "#QandA">FAQs</a></li>
					<li id="g" class="left"><a href = "#userguide">User Guide</a></li>

				</ul>

			</nav>



			<section id="drillDown1">
				<center>
					<div id="c0" style=" width:1100px;"><canvas id="chart-0"></canvas></div>
					<div id="c1" hidden ="hidden" style="width:1100px;"><canvas id="chart-1" ></canvas></div>
					<div id="c2" hidden ="hidden" style="width:1100px;"><canvas id="chart-2" ></canvas></div>
					<div id="c3" hidden ="hidden" style="width:1200px;"><canvas id="chart-3" ></canvas></div>
					<div id="c4" hidden ="hidden" style="width:1200px;"><canvas id="chart-4" ></canvas></div>
				</center>
			</section>


			<div id="QandA" hidden = "hidden">
				<div class="pad">

					<HR>
					<H3 align="center">FAQs</H3>

					<H2>Q1. What do the charts show on curriculum page?</H2></br>
					     Ans. Curriculum page shows different types of charts that represent number of units that contribute to a specific UN set sustainable development goal.</br></br>
					<H2>Q2. What do the charts show once I click on any unit?</H2></br>
					     Ans. Unit page shows charts that represent number of goals hit by that specific unit.</br></br>
					<H2>Q3. What happens once clicked on a section of chart?</H2></br>
					     Ans. It shows a table that displays all the units hit on the clicked goal(section of chart) and where in the unit did that hit i.e Assesment, learning outcome or unit content.</br></br>
					<H2>Q4. What does the number outside pie chart show?</H2></br>
					     Ans. It shows the number of units hitting on that goal.</br></br>
                    <H2>Q5. How do I get back to the initial curriculum page with all of the SDGs after selecting a unit?</H2></br>
     				     Ans. Select the "Curriculum" option in the bottom nav bar or select the "Sustainable Development Goals Tracker" text next to the Murdoch logo above the top menu bar.</br></br>
                    <H2>Q6. How do I view a specific unit without finding it in the list of units meeting a specific goal?</H2></br>
     				     Ans. Enter the unit code (eg. ICT302) into the search box on the right side of the menu bar and then press enter or select the search button.</br></br>
                    <H2>Q7. How do i filter out SDGs from showing in the graphs?</H2></br>
                          Ans. Select the SDG name in the graph legend on the left, this acts as a toggle and will remove/add the SDG data from being displayed in the graph.</br></br>
                    <HR>
				</div>
			</div>


			<div id="userguide" hidden = "hidden">
				<div class="pad">

					<HR>
					<H3 align = "center"> User Guide </H3>
					<H2>General usage and navigation</H2></br>
					     The landing page of the Murdoch University Sustainable Development Goal (SDG) Tracker initially shows the menu bar under the standard Murdoch header, this menu includes buttons to select the 5 chart types to visualise the data, the FAQs and User Guide you are reading now, and finally a search box to view an individual unit's data.</br>
                         <img src="./img/UserGuideImages/menu.png" align="top"></br>
					     The 5 charts available are polar area, pie, radar, line, and the bar graph. Initially the Polar Area chart will be displayed, simply choose your preferred chart in the menu bar above to change the chart type.</br>
					     The selected chart can be changed at any time by selecting a different chart in the menu bar.</br>
					     The FAQs and User Guide links will show helpful information regarding the usage of the Murdoch University SDG Tracker.</br>
					     The search box on the right allows you to search for a specific unit without having to find it using the 2nd level drill down (explained below).</br>
                         <img src="./img/UserGuideImages/search.png" align="top"></br>
                         There are two separate pages used for the SDG Tracker, the curriculum.php and the unit.php, to navigate back to the curriculum page from the unit page you can use the "Curriculum" link in the bottom navigation bar or you can select the "Sustainable Development Goals Tracker" title at the top of the page. Alternatively you can also use the web browser back button.</br>
                         <img src="./img/UserGuideImages/title.png" align="top"><span>&#032;</span><img src="./img/UserGuideImages/curriculumlink.png" align="top"></br></br>
					<H2>1st level: 17 SDG Overview</H2></br>
					     Once the preferred chart is chosen, the current data will be visualised showing how many units total are achieving each of the 17 SDGs.</br>
					     Each of the 17 SDGs can be filtered out from being displayed in the chart by clicking the SDG you wish to remove in the legend on the left of the chart, to display the SDG again simply click it in the legend again.</br>
                         <img src="./img/UserGuideImages/filter.png" align="top"></br>
					     You can hover over the sections of the chart to view the exact data value for that SDG if the numbering around the edge is hard to read.</br>
					     To access the 2nd level drill down, simply select the SDG you wish to view on whichever chart you are currently using, you need to select the SDG on the chart and NOT on the legend to access the 2nd level drill down.</br>
                         <img src="./img/UserGuideImages/chartselect.png" align="top"><br/></br>
					<H2>2nd level: Individual SDG Overview</H2></br>
					     Once a SDG is selected on the chart, a table will be shown below the chart with the title of the selected SDG and a list of all units that have achieved that SDG along with where they achieved the SDG (ie. in their unit content, learning outcome, or assessments).</br>
					     To change the selected SDG simple select the next SDG you wish to view on the chart at the top.
					     To view an individual unit's information and which SDGs it is achieving, you can select the unit code from the table below the chart, or you can enter the unit code (eg. ICT302) into the search bar on the right side of the menu.</br>
                         <img src="./img/UserGuideImages/unit.png" align="top"></br></br>
					<H2>3rd level: Individual Unit Overview</H2></br>
					     Once a unit is selected or searched, the unit page will be loaded and the data for the specific unit chosen will be shown.</br>
					     A table will be populated with each of the SDGs the unit is achieving, along with which section of the unit is achieving each SDG.
					     The unit information is also included on this page to inform the user of the information provided to the system that was analysed to produce the output of SDGs it achieves.</br>
					     To view the unit information, select the relevant option in the drop down labelled "--View unit details--" underneath the chart.</br>
                         <img src="./img/UserGuideImages/unitdetails.png" align="top"></br>
					     You can also select a chart from the menu to visualise the SDGs the unit is achieving.</br></br>

                    <HR>
				</div>
			</div>

			<section id="drillDown2">
				<div id ="Tables"> <table id="SDGHitDescTable"> </table> </div>
			</section>

                <?php

                        $con = mysqli_connect("localhost", "root", "1C+302$@l", "SDG");

    if (mysqli_connect_errno())
    {
        echo'connect fail';
        die(); //Kill the script so the user can't peek at any errors our code may produce.
        //mysqli_connect_error();
    }

                    $query = "SELECT * FROM Unit2SDG";
                    $result = mysqli_query($con, $query);

                	if (mysqli_num_rows($result) > 0)
                    {
                        //output data of each row
                        echo '<div> ';
                        $hits= array();
                        while ($row = mysqli_fetch_array($result))
                        {
                          $hits[] = $row['HitCount'];
                          $goal_name[] = $row['SDG'];
						  $year[] = $row['Year'];
                        }
                        echo '</div>';
                    }




					//query the table 2 for creating the tables
					$query2 = "SELECT * FROM SDGHitDesc where HiTFlagedIn LIKE '%hit%'";
                    $result2 = mysqli_query($con, $query2);

					if (mysqli_num_rows($result2) > 0)
                    {
                        //output data of each row
                        echo '<div> ';
                        while ($row = mysqli_fetch_array($result2))
                        {
                          $unitCode2[] = $row['UnitCode'];
			  $unitTitle2[] = $row['UnitTitle'];
                          $goal_name2[] = $row['SDG'];
			  $year2[] = $row['Year'];
			  $hitOnSection[] = $row['HiTFlagedIn'];
                        }
                        echo '</div>';
                    }




                	mysqli_close($con);
                ?>
                <script type="text/javascript">
                var hits = <?php echo json_encode($hits); ?>;
                var goal_name = <?php echo json_encode($goal_name); ?>;
				var year = <?php echo json_encode($year); ?>;



				var unitCode2 = <?php echo json_encode($unitCode2); ?>;
              <!--  var unitTitle2 = <?php echo json_encode($unitTitle2); ?>;		-->
				var goal_name2 = <?php echo json_encode($goal_name2); ?>;
				var year2 = <?php echo json_encode($year2); ?>;
				var hitOnSection = <?php echo json_encode($hitOnSection); ?>;

                </script>
                <!-- dark overlay when nav opens -->




			<div id="bottom_nav">
				<center>
					<ul class="bottom_nav_list">
						<li class="bottom_nav_item">
							<a style="background-color:rgba(0,0,0,0);" class="bottom_nav_link" href="index.php">
								<img src="img/icons/arrow-left.svg" width="50" height="50">
							</a>
						</li>
						<li class="bottom_nav_item">
							<a class="bottom_nav_link" href="index.php">UN Goals</a>
						</li>
						<li class="bottom_nav_item">
							<a class="bottom_nav_link" href="curriculum.php">Curriculum</a>
						</li>
						<li class="bottom_nav_item">
							<a class="bottom_nav_link" href="map.php">Campus Map</a>
						</li>


						<li class="bottom_nav_item">
							<a style="background-color:rgba(0,0,0,0);" class="bottom_nav_link" href="curriculum.php">
								<img src="img/icons/arrow-right.svg" width="50" height="50">
							</a>
						</li>
					</ul>
				</center>
			</div>
			
</main>


            <footer id="footer" class="footer">
                <div class="footer__top">
                    <div class="row-wrap">
                        <div class="site-logo site-logo--footer"> <a href="https://www.murdoch.edu.au/"></a> </div>
                        <div class="footer__social-links">
                            <ul>
                                <li><a class="btn-social--twitter" href="https://twitter.com/murdochuni" target="_blank" title="Twitter">Twitter</a></li>
                                <li><a class="btn-social--facebook" href="https://www.facebook.com/MurdochUniversity/" target="_blank" title="Facebook">Facebook</a></li>
                                <li><a class="btn-social--instagram" href="https://instagram.com/MurdochUniversity/" target="_blank" title="Instagram">Instagram</a></li>
                                <li><a class="btn-social--youtube" href="https://www.youtube.com/user/murdochdigitalmedia" target="_blank" title="YouTube">YouTube</a></li>
                                <li><a class="btn-social--linkedin" href="https://www.linkedin.com/edu/school?id=10232" target="_blank" title="LinkedIn">LinkedIn</a></li>
                            </ul>
                        </div>
                    </div>
                    <nav class="footer__nav" role="navigation" data-accordion-mobile="" data-allow-all-closed="true">
                        <div class="col accordion-item" data-accordion-item="">
                            <a href="#">
                                <h3>Information for</h3>
                            </a>
                            <h3>Information For</h3>
                            <ul data-tab-content="">
                                <li>
                                    <a href="https://www.murdoch.edu.au/study">Future students</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/study/international-students/">International students</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/research-capabilities">Researchers</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/teachers-and-career-advisors">Teachers &amp; career advisors</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/parents-and-families">Parents &amp; families</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/alumni-and-giving">Alumni</a>
                                </li>
                                <li>
                                    <a href="http://www.murdoch.edu.au/Support-Murdoch/">Donors</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/industry-and-community">Industry &amp; community</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col accordion-item" data-accordion-item="">
                            <a href="#">
                                <h3>Quick links</h3>
                            </a>
                            <h3>Quick links</h3>
                            <ul data-tab-content="">
                                <li>
                                    <a href="https://www.murdoch.edu.au/study/apply-to-murdoch">Apply to Murdoch</a>
                                </li>
                                <li>
                                    <a target="_blank" href="https://www.murdoch.edu.au/library">Library</a>
                                </li>
                                <li>
                                    <a href="https://my.murdoch.edu.au/" target="_blank">My Murdoch</a>
                                </li>
                                <li>
                                    <a href="http://wwwcoms.murdoch.edu.au/directory/" target="_blank">Staff Directory</a>
                                </li>
                                <li>
                                    <a href="http://www.murdoch.edu.au/Learning-and-Teaching/">Learning &amp; Teaching</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/about-us/work-at-murdoch" target="_blank">Work at Murdoch</a>
                                </li>
                                <li>
                                    <a href="http://www.murdoch.edu.au/Contact-us/Feedback/" target="_blank">Provide feedback</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col accordion-item" data-accordion-item="">
                            <a href="#">
                                <h3>Murdoch Global</h3>
                            </a>
                            <h3>Murdoch Global</h3>
                            <ul data-tab-content="">
                                <li>
                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus">Perth</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/rockingham-campus">Rockingham</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/mandurah-campus">Mandurah</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/international-campuses/singapore">Singapore</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/international-campuses/dubai" target="_blank">Dubai</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col contact-details">
                            <h3>Contact Us</h3>
                            <ul>
                                <li>General enquiries<br>
                                    <a href="tel:+61893606000">+61 8 9360 6000</a>
                                </li>
                                <li><a href="https://www.murdoch.edu.au/contact-us/" class="link link--arrow-r link--red">Future student enquiries</a></li>
                                <li><a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/security" class="link link--arrow-r link--red">Help &amp; emergencies</a></li>
                                <li>
                                    <address>Perth campus<br>
                                        90 South Street, Murdoch<br>
                                        Western Australia 6150
                                    </address>
                                </li>
                                <li><small>(15 mins from the city centre of Perth)</small></li>
                                <li><a href="https://goo.gl/maps/4cENbz6TsMA2" class="link link--arrow-r link--red"><em aria-hidden="true" class="fa fa-map-marker"></em> Get directions</a></li>
                                <li><a href="https://www.murdoch.edu.au/ResourcePackages/Murdoch/360/Perthcampustour/murdochVT.html" class="link link--arrow-r link--red" target="_blank"><em aria-hidden="true" class="fa fa-map-marker"></em> Campus
                                        virtual tour</a></li>
                                <li><a href="https://www.murdoch.edu.au/life-at-murdoch/maps-and-tours" class="link link--arrow-r link--red"><em aria-hidden="true" class="fa fa-map-marker"></em> Download campus map</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
                <div class="footer__message">
                    <div class="row-wrap">
                        <div class="article  article--row">
                            <p>We acknowledge the Whadjuk people of the Noongar nation as the
                                traditional custodians of this country and its waters and that Murdoch
                                University stands on Noongar country. We pay our respects to Noongar
                                elders past and present, and acknowledge their wisdom and advice in our
                                teaching and cultural knowledge activities.
                            </p>
                            <a href="http://www.murdoch.edu.au/Kulbardi/" class="link link--arrow-r link--red">Kulbardi Aboriginal Centre</a>
                        </div>
                    </div>
                </div>
                <nav class="footer__lower">
                    <div class="row-wrap">
                      <div>
                        <div>
                          <ul data-tab-content="">
                            <li><a target="_blank" href="http://goto.murdoch.edu.au/TEQSANumber">TEQSA number: PRV12163</a></li>
                            <li><a target="_blank" href="http://goto.murdoch.edu.au/CRICOSCode">CRICOS Code: 00125J</a></li>
                            <li><a target="_blank" href="http://goto.murdoch.edu.au/CopyrightNotice">Copyright &amp; Disclaimer</a></li>
                            <li><a target="_blank" href="https://goto.murdoch.edu.au/Privacy">Privacy</a></li>
                            <li>&copy; Murdoch University</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                </nav>
            </footer>
        </div>
    </div>

<!--	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js" > </script>  -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src='js/jquery-3.3.1.js'></script>
	<script src='js/jquery.rwdImageMaps.min.js'></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/utils.js"></script>
	<script src="js/charts.js"></script>
	<script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.bundle.js'></script>
	<script src='https://cdn.jsdelivr.net/gh/emn178/chartjs-plugin-labels/src/chartjs-plugin-labels.js'></script>
<!--    <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js'></script> -->

	 <script src="js/Navigation.js"></script>
	 <link rel = "stylesheet"   type = "text/css" href = "css/nav_chart.css" />
	 <link rel = "stylesheet"   type = "text/css" href = "css/table.css" />
	<body style="background-color: #FAF5F9; ">
    </body>

</html>
