<!DOCTYPE html>
<html class=" localstorage no-flexboxtweener" lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="Murdoch%20University_files/styles.css" rel="stylesheet" type="text/css">
        <title>
        Murdoch University
        </title>
        <link rel="icon" type="image/png" href="https://static.murdoch.edu.au/precedent/images/favicon-16x16.png" sizes="32x32">
        <link rel="icon" type="image/png" href="https://static.murdoch.edu.au/precedent/images/favicon-32x32.png" sizes="16x16">
        <link rel="icon" type="image/ico" href="https://static.murdoch.edu.au/precedent/images/favicon.ico" sizes="48x48">
        <meta name="Generator" content="Sitefinity 10.1.6532.0 PU">
        <meta class="foundation-mq">
        <link rel ="stylesheet" href="./css/widget.css" />
        <link rel ="stylesheet" href="./css/ungoal.css"/>
        <link href="http://www.cssscript.com/wp-includes/css/sticky.css" rel="stylesheet" type="text/css"/>

        <link rel="stylesheet" type="text/css" href="./css/slick/slick.css"/>
        
        <link rel="stylesheet" type="text/css" href="./css/slick/slick-theme.css"/>


        <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" />
        <link id="yui__dyn_1" type="text/css" charset="utf-8" rel="stylesheet" href="Murdoch%20University_files/ConditionalChatLink.css"/>

        <style type="text/css">
    html, body {
      margin: 0;
      padding: 0;
    }

    * {
      box-sizing: border-box;
    }


    .slider {
        width: 90%;
    height:300px;
        margin: 100px auto;
    }
.content
{
    margin-bottom:10em;
}
h1
{
    font-size: 35px;
    text-align: center;
    margin-top: 2rem;
color:#fff;
    
}

.slider h3{
    margin-top:2rem;
    font-size:18px;
color:#fff;
}

.slider .white{
color:#fff;
}

.slider h1{
    text-align:centre;
    
}

    .slick-slide {
      margin: 0px 20px;
    }

    .slick-slide img {
      width: 14em;
        margin-right:8em;
            margin-left: 8em;
        
    }
.red {
color:red;
}

    .slick-prev:before,
    .slick-next:before {
      color: black;
    }


    .slick-slide {
      transition: all ease-in-out .3s;
      opacity: .2;
    }
    
    .slick-active {
      opacity: .5;
    }

    .slick-current {
      opacity: 1;
    }
  </style>
    </head>
    <body>
        <svg class="sr-only">
            <defs>
                <!-- Arrow on bottom -->
                <g id="s-shape-1">
                    <path d="M373.2,671.3l22.1-22.1H720V0H0v649.1h338l22.1,22.1C363.7,674.9,369.6,674.9,373.2,671.3z"></path>
                </g>
                <!-- Arrow on top -->
                <g id="s-shape-2">
                    <path d="M346.8,2.7l-22.1,22.1H0V674h720V24.9H382L359.9,2.8C356.3-0.9,350.4-0.9,346.8,2.7z"></path>
                </g>
                <!-- Blue gradient -->
                <linearGradient id="s-gradient-1" gradientUnits="userSpaceOnUse" x1="-12.286" y1="668.6664" x2="612.3149" y2="44.0655" gradientTransform="matrix(1 0 0 -1 0 682)">
                    <stop offset="0.1189" style="stop-color:#334690"></stop>
                    <stop offset="0.8189" style="stop-color:#3080c2"></stop>
                </linearGradient>
                <!-- Green gradient -->
                <linearGradient id="s-gradient-2" gradientUnits="userSpaceOnUse" x1="-12.286" y1="668.6664" x2="612.3149" y2="44.0655" gradientTransform="matrix(1 0 0 -1 0 682)">
                    <stop offset="0.2486" style="stop-color:#5C9832"></stop>
                    <stop offset="0.8189" style="stop-color:#209886"></stop>
                </linearGradient>
                <!-- Yellow gradient -->
                <linearGradient id="s-gradient-3" gradientUnits="userSpaceOnUse" x1="-12.286" y1="668.6664" x2="612.3149" y2="44.0655" gradientTransform="matrix(1 0 0 -1 0 682)">
                    <stop offset="0.2486" style="stop-color:#f5b423"></stop>
                    <stop offset="0.8189" style="stop-color:#feca32"></stop>
                </linearGradient>
                <!-- Red gradient -->
                <linearGradient id="s-gradient-4" gradientUnits="userSpaceOnUse" x1="-12.286" y1="668.6664" x2="612.3149" y2="44.0655" gradientTransform="matrix(1 0 0 -1 0 682)">
                    <stop offset="0.2486" style="stop-color:#e90915"></stop>
                    <stop offset="0.8189" style="stop-color:#f9383a"></stop>
                </linearGradient>
            </defs>
        </svg>
        <div class="sfPublicWrapper" id="PublicWrapper">
            <div id="wrap" class="">
                <header id="header" class="header header--mobile header--narrow" data-page-scroll-element="window" data-header-responsive-offsets="0-0-0|639-69-69|1025-117-69" data-narrow-header="">
                    <a href="#skip-to-content" class="sr-only sr-only-focusable">Skip to main content</a>
                    <div class="header__logo">
                        <div class="site-logo"> <a href="https://www.murdoch.edu.au/" title="Murdoch University home"></a> </div>
                    </div>
                    <nav class="header__top" role="navigation">
                        <div class="row-header">
                            <ul>
                                <li>
                                    <a href="http://our.murdoch.edu.au/Students/" class="link link--white link--fa-r fa-external-link" target="_blank">Current Students</a>
                                </li>
                                <li>
                                    <a target="_blank" class="link link--white link--fa-r fa-external-link" href="http://our.murdoch.edu.au/Staff/">Staff</a>
                                </li>
                                <li>
                                    <a class="link link--white" href="http://www.murdoch.edu.au/contact-us/">Contact us</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/global" class="link link--white">Global</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                    <div id="header-banner" class="header__banner">
                        <div class="row-header">
                            <div class="header__main">
                                <nav class="nav-main" role="navigation">
                                    <ul>
                                        <li>
                                            <a href="https://www.murdoch.edu.au/study" target="_self" class="">Study</a>
                                        </li>
                                        <li>
                                            <a href="https://www.murdoch.edu.au/life-at-murdoch" target="_self" class="">Life at Murdoch</a>
                                        </li>
                                        <li>
                                            <a href="https://www.murdoch.edu.au/research-capabilities" target="_self" class="">Research</a>
                                        </li>
                                        <li>
                                            <a href="https://www.murdoch.edu.au/industry-and-community" target="_self" class="">Industry &amp; Community</a>
                                        </li>
                                        <li>
                                            <a href="https://www.murdoch.edu.au/alumni-and-giving" target="_self" class="">Alumni &amp; Giving</a>
                                        </li>
                                        <li>
                                            <a href="https://www.murdoch.edu.au/about-us" target="_self" class="">About Us</a>
                                        </li>
                                    </ul>
                                </nav>
                                <!-- main site search - slides open     from the right -->
                                <!--<div class="site-search">
                                 <div class="site-search__form">
                                 <form id="form_search" enctype="application/x-www-form-urlencoded" method="get" action="https://search.murdoch.edu.au/s/search.html" name="search_form">
                                 <input class="site-search__input" placeholder="Search the Site" name="query" autocomplete="off" type="search">
                                 <button type="submit" class="site-search__submit" value="Search">Search</button>
                                 <input name="collection" value="mu-meta" type="hidden">
                                 </form>
                                 </div>
                                 <div class="site-search__toggle">
                                 <button type="button" id="searchToggle" class="search-toggle">
                                 <span class="">Search Toggle</span>
                                 </button>
                                 </div>
                                 </div> -->
                            </div>
                        </div>
                    </div>
                </header>
                <!--<nav id="navPrimary" class="nav-slide nav--mobile" role="navigation" aria-label="navToggle">
                    <div class="wrapper">
                        <div class="nav-level active in">
                            <div class="nav-list" style="height: 957px; overflow-y: hidden;">
                                <ul style="margin-top: 0px;">
                                    <li>
                                        <a class="nav-button" href="https://www.murdoch.edu.au/study"><span>Study</span></a>
                                        <button>Open submenu</button>
                                        <div class="nav-level" aria-label="submenu">
                                            <div class="nav-list">
                                                <div class="nav__title">
                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                    <a href="https://www.murdoch.edu.au/study">
                                                        <h3>Study</h3>
                                                    </a>
                                                </div>
                                                <ul>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/courses"><span>Courses</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/courses">
                                                                        <h3>Courses</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/courses/course-finder" target="_self"><span>Find a Course</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/study-areas"><span>Study areas</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/study-areas">
                                                                        <h3>Study areas</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-areas/technology" target="_self"><span>Technology</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-areas/science" target="_self"><span>Science</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-areas/health" target="_self"><span>Health</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-areas/creative-arts-and-communication" target="_self"><span>Creative Arts &amp; Communication</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-areas/engineering" target="_self"><span>Engineering</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-areas/business-and-law" target="_self"><span>Business and Law</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-areas/teaching" target="_self"><span>Teaching</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-areas/social-cultural-studies" target="_self"><span>Social &amp; Cultural Studies</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/study-online"><span>Study online</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/study-online">
                                                                        <h3>Study online</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-online/graduate-certificate-in-health-administration-policy-and-leadership-online" target="_self"><span>Health Administration, Policy and Leadership</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-online/one-health" target="_self"><span>One Health</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/why-choose-murdoch"><span>Why choose Murdoch?</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/why-choose-murdoch">
                                                                        <h3>Why choose Murdoch?</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/why-choose-murdoch/meet-our-free-thinkers" target="_self"><span>Meet our Free Thinkers</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/decide-what-to-study"><span>Decide what to study</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/decide-what-to-study">
                                                                        <h3>Decide what to study</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/decide-what-to-study/what-is-an-atar" target="_self"><span>What is an ATAR?</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/decide-what-to-study/types-of-courses" target="_self"><span>Types of courses</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/decide-what-to-study/the-career-learning-spine" target="_self"><span>The Career Learning Spine</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/decide-what-to-study/flexible-learning-options" target="_self"><span>Flexible learning options</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/decide-what-to-study/study-a-single-unit" target="_self"><span>Study a single unit</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/decide-what-to-study/double-majors-minors-and-combined-degrees" target="_self"><span>Double majors, minors and combined degrees</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/decide-what-to-study/advanced-standing" target="_self"><span>Advanced Standing</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students"><span>Undergraduate students</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students">
                                                                        <h3>Undergraduate students</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/admissions-pathways"><span>Admissions pathways</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/admissions-pathways">
                                                                                        <h3>Admissions pathways</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/admissions-pathways/you-recently-finished-secondary-education" target="_self"><span>You recently finished secondary education</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/admissions-pathways/you-have-previous-vocational-study" target="_self"><span>You have previous vocational study</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/admissions-pathways/you-have-previous-higher-education-study" target="_self"><span>You have previous higher education study </span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/admissions-pathways/you-have-work-and-life-experience" target="_self"><span>You have work and life experience</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/admissions-pathways/other-options" target="_self"><span>Other options</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/fees-scholarships"><span>Fees &amp; scholarships</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/fees-scholarships">
                                                                                        <h3>Fees &amp; scholarships</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/fees-scholarships/course-fees" target="_self"><span>Course fees</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/fees-scholarships/other-fees" target="_self"><span>Other fees</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/fees-scholarships/living-costs" target="_self"><span>Living costs</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/fees-scholarships/scholarships" target="_self"><span>Scholarships</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/how-to-apply"><span>How to apply</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/how-to-apply">
                                                                                        <h3>How to apply</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/how-to-apply/apply-through-tisc"><span>Apply through TISC</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/how-to-apply/apply-through-tisc">
                                                                                                        <h3>Apply through TISC</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/how-to-apply/apply-through-tisc/choose-your-tisc-preferences" target="_self"><span>Choose your TISC preferences</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/how-to-apply/apply-online" target="_self"><span>Apply online</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/how-to-apply/apply-through-an-agent"><span>Apply through an agent</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/how-to-apply/apply-through-an-agent">
                                                                                                        <h3>Apply through an agent</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/how-to-apply/apply-through-an-agent/find-an-agent" target="_self"><span>Find an Agent</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/accepting-your-offer" target="_self"><span>Accepting your offer</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/orientation" target="_self"><span>Orientation</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources"><span>Events &amp; resources</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources">
                                                                                        <h3>Events &amp; resources</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/future-students"><span>Future students</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/future-students">
                                                                                                        <h3>Future students</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/future-students/murdoch-horizons-year-12-summer-school" target="_self"><span>Murdoch Horizons Year 12 Summer School</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/teachers-and-career-advisors"><span>Teachers and career advisors</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/teachers-and-career-advisors">
                                                                                                        <h3>Teachers and career advisors</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/teachers-and-career-advisors/student-workshops" target="_self"><span>Student workshops</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/teachers-and-career-advisors/school-programs" target="_self"><span>School programs</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/teachers-and-career-advisors/careers-masterclass" target="_self"><span>Careers Masterclass</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/parents-and-families" target="_self"><span>Parents and families</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/honours-students"><span>Honours students</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/honours-students">
                                                                        <h3>Honours students</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/honours-students/entry-requirements" target="_self"><span>Entry requirements</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/honours-students/fees-scholarships"><span>Fees &amp; scholarships</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/honours-students/fees-scholarships">
                                                                                        <h3>Fees &amp; scholarships</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/honours-students/fees-scholarships/course-fees" target="_self"><span>Course fees</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/honours-students/fees-scholarships/other-fees" target="_self"><span>Other fees</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/honours-students/fees-scholarships/living-costs" target="_self"><span>Living costs</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/honours-students/fees-scholarships/scholarships" target="_self"><span>Scholarships</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/honours-students/how-to-apply"><span>How to apply</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/honours-students/how-to-apply">
                                                                                        <h3>How to apply</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/honours-students/how-to-apply/apply-through-an-agent"><span>Apply through an agent</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/study/honours-students/how-to-apply/apply-through-an-agent">
                                                                                                        <h3>Apply through an agent</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/honours-students/how-to-apply/apply-through-an-agent/find-an-agent" target="_self"><span>Find an Agent</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/honours-students/accepting-your-offer" target="_self"><span>Accepting your offer</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students"><span>Postgraduate students</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/postgraduate-students">
                                                                        <h3>Postgraduate students</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students/entry-requirements" target="_self"><span>Entry requirements</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students/fees-scholarships"><span>Fees &amp; scholarships</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/postgraduate-students/fees-scholarships">
                                                                                        <h3>Fees &amp; scholarships</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students/fees-scholarships/course-fees" target="_self"><span>Course fees</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students/fees-scholarships/other-fees" target="_self"><span>Other fees</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students/fees-scholarships/living-costs" target="_self"><span>Living costs</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students/fees-scholarships/scholarships" target="_self"><span>Scholarships</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students/how-to-apply"><span>How to apply</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/postgraduate-students/how-to-apply">
                                                                                        <h3>How to apply</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students/how-to-apply/apply-through-an-agent"><span>Apply through an agent</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/study/postgraduate-students/how-to-apply/apply-through-an-agent">
                                                                                                        <h3>Apply through an agent</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students/how-to-apply/apply-through-an-agent/find-an-agent" target="_self"><span>Find an Agent</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students/accepting-your-offer" target="_self"><span>Accepting your offer</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/postgraduate-students/orientation" target="_self"><span>Orientation</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/research-students"><span>Research students</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/research-students">
                                                                        <h3>Research students</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/research-students/entry-requirements" target="_self"><span>Entry requirements</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/research-students/your-research-project"><span>Your research project</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/research-students/your-research-project">
                                                                                        <h3>Your research project</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/your-research-project/choosing-a-research-topic" target="_self"><span>Choosing a research topic</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/your-research-project/finding-a-supervisor" target="_self"><span>Finding a supervisor</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/research-students/how-to-apply" target="_self"><span>How to apply</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/research-students/accepting-your-offer"><span>Accepting your offer</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/research-students/accepting-your-offer">
                                                                                        <h3>Accepting your offer</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/accepting-your-offer/receiving-an-offer" target="_self"><span>Receiving an offer</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/accepting-your-offer/getting-started" target="_self"><span>Getting started</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships"><span>Fees &amp; scholarships</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships">
                                                                                        <h3>Fees &amp; scholarships</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/fees" target="_self"><span>Fees</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/living-costs" target="_self"><span>Living costs</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships"><span>Scholarships</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships">
                                                                                                        <h3>Scholarships</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/government-of-western-australia-china-scholarship" target="_self"><span>Government of Western Australia China Scholarship</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/research-training-program-stipend-scholarships" target="_self"><span>Research Training Program Stipend Scholarships</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/kulbardi-postgraduate-research-degree-scholarship" target="_self"><span>Kulbardi Postgraduate Research Degree Scholarship </span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/potato-research-wa" target="_self"><span>Potato Research WA</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/grains-research-and-development-corporation" target="_self"><span>Grains Research and Development Corporation</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/the-lowitja-institute-starlight-children-s-foundation-scholarship" target="_self"><span>The Lowitja Institute Starlight Children’s Foundation Scholarship</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/harry-butler-institute-phd-scholarship" target="_self"><span>Harry Butler Institute PhD Scholarship</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/jon-rock-travel-scholarship" target="_self"><span>Jon Rock Travel Scholarship</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/extractive-metallurgy-of-lithium-scholarships" target="_self"><span>Extractive Metallurgy of Lithium Scholarships</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/southeast-asian-environmental-history-phd-scholarship" target="_self"><span>Southeast Asian Environmental History PhD Scholarship</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/geoffrey-bolton-history-scholarship" target="_self"><span>Geoffrey Bolton History Scholarship</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/csiro-phd-top-up-scholarship" target="_self"><span>CSIRO PhD Top-up Scholarship</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/research-students/fees-scholarships/scholarships/keiran-mcnamara-world-heritage-phd-top-up-scholarship" target="_self"><span>Keiran McNamara World Heritage PhD Top-up Scholarship</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/research-students/life-as-a-research-student" target="_self"><span>Life as a research student</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/international-students"><span>International students</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/international-students">
                                                                        <h3>International students</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/international-students/life-in-perth"><span>Life in Perth</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/international-students/life-in-perth">
                                                                                        <h3>Life in Perth</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/life-in-perth/facts-about-perth-wa" target="_self"><span>Facts about Perth, WA</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/life-in-perth/things-to-do-in-around-perth" target="_self"><span>Things to do in and around Perth</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/life-in-perth/climate-culture" target="_self"><span>Climate &amp; culture</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/life-in-perth/accommodation"><span>Accommodation</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/study/international-students/life-in-perth/accommodation">
                                                                                                        <h3>Accommodation</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/life-in-perth/accommodation/students-under-18-years-of-age" target="_self"><span>Students under 18 years of age</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/life-in-perth/living-costs" target="_self"><span>Living costs</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/international-students/studying-at-murdoch"><span>Studying at Murdoch</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/international-students/studying-at-murdoch">
                                                                                        <h3>Studying at Murdoch</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/studying-at-murdoch/life-on-campus" target="_self"><span>Life on campus</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/studying-at-murdoch/international-student-groups" target="_self"><span>International student groups</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/studying-at-murdoch/support-services" target="_self"><span>Support services</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/studying-at-murdoch/information-for-parents" target="_self"><span>Information for parents</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/studying-at-murdoch/fees-and-scholarships"><span>Fees and scholarships</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/study/international-students/studying-at-murdoch/fees-and-scholarships">
                                                                                                        <h3>Fees and scholarships</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/studying-at-murdoch/fees-and-scholarships/financial-aid-and-student-loans" target="_self"><span>Financial aid and student loans</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/studying-at-murdoch/fees-and-scholarships/scholarships" target="_self"><span>Scholarships</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/international-students/entry-requirements" target="_self"><span>Entry requirements</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/international-students/before-moving-to-perth"><span>Before moving to Perth</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/international-students/before-moving-to-perth">
                                                                                        <h3>Before moving to Perth</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/before-moving-to-perth/apply-for-a-visa" target="_self"><span>Apply for a visa</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/before-moving-to-perth/relocating-as-a-family" target="_self"><span>Relocating as a family</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/before-moving-to-perth/overseas-student-health-cover" target="_self"><span>Overseas student health cover</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/international-students/arrival-in-perth"><span>Arrival in Perth</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/international-students/arrival-in-perth">
                                                                                        <h3>Arrival in Perth</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/arrival-in-perth/airport-pickups" target="_self"><span>Airport pickups</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/arrival-in-perth/getting-organised" target="_self"><span>Getting organised</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/arrival-in-perth/orientation" target="_self"><span>Orientation</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/international-students/arrival-in-perth/working-in-perth" target="_self"><span>Working in Perth</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/international-students/study-abroad-exchange" target="_self"><span>Study abroad &amp; exchange</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/study-abroad"><span>Study abroad</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/study-abroad">
                                                                        <h3>Study abroad</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-abroad/coming-to-murdoch"><span>Coming to Murdoch</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/study-abroad/coming-to-murdoch">
                                                                                        <h3>Coming to Murdoch</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/study-abroad/coming-to-murdoch/decide-what-to-study"><span>Decide what to study</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/study/study-abroad/coming-to-murdoch/decide-what-to-study">
                                                                                                        <h3>Decide what to study</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/study-abroad/coming-to-murdoch/decide-what-to-study/short-courses" target="_self"><span>Short courses</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/study/study-abroad/coming-to-murdoch/decide-what-to-study/study-abroad-specialised-certificates" target="_self"><span>Study Abroad Specialised Certificates</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/study-abroad/coming-to-murdoch/how-to-apply" target="_self"><span>How to apply</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/study-abroad/coming-to-murdoch/fees-and-scholarships" target="_self"><span>Fees and scholarships</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/study-abroad/coming-to-murdoch/life-on-campus" target="_self"><span>Life on campus</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/study-abroad/coming-to-murdoch/when-you-leave" target="_self"><span>When you leave</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-abroad/going-overseas" target="_self"><span>Going overseas</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/study-abroad/partner-universities" target="_self"><span>Partner universities</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/fees-scholarships"><span>Fees &amp; scholarships</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/study/fees-scholarships">
                                                                        <h3>Fees &amp; scholarships</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/fees-scholarships/course-fees"><span>Course fees</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/study/fees-scholarships/course-fees">
                                                                                        <h3>Course fees</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/fees-scholarships/course-fees/paying-your-fees" target="_self"><span>Paying your fees</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/study/fees-scholarships/course-fees/applying-for-a-help-loan" target="_self"><span>Applying for a HELP loan</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/fees-scholarships/other-fees" target="_self"><span>Other fees</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/fees-scholarships/living-costs" target="_self"><span>Living costs</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/study/fees-scholarships/scholarships" target="_self"><span>Scholarships</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/study/apply-to-murdoch" target="_self"><span>Apply to Murdoch</span></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-button" href="https://www.murdoch.edu.au/life-at-murdoch"><span>Life at Murdoch</span></a>
                                        <button>Open submenu</button>
                                        <div class="nav-level" aria-label="submenu">
                                            <div class="nav-list">
                                                <div class="nav__title">
                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch">
                                                        <h3>Life at Murdoch</h3>
                                                    </a>
                                                </div>
                                                <ul>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture"><span>Campus life &amp; culture</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture">
                                                                        <h3>Campus life &amp; culture</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/the-guild" target="_self"><span>The Guild</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities"><span>Facilities</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities">
                                                                                        <h3>Facilities</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/library" target="_self"><span>Library</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/bookshop" target="_self"><span>Bookshop</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/worship-centre" target="_self"><span>Worship Centre</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/murdoch-university-art-collection"><span>Murdoch University Art Collection</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/murdoch-university-art-collection">
                                                                                                        <h3>Murdoch University Art Collection</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/murdoch-university-art-collection/about-the-collection"><span>About the Collection</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                                            <div class="nav-list">
                                                                                                                <div class="nav__title">
                                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/murdoch-university-art-collection/about-the-collection">
                                                                                                                        <h3>About the Collection</h3>
                                                                                                                    </a>
                                                                                                                </div>
                                                                                                                <ul>
                                                                                                                    <li>
                                                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/murdoch-university-art-collection/about-the-collection/history" target="_self"><span>History</span></a>
                                                                                                                    </li>
                                                                                                                    <li>
                                                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/murdoch-university-art-collection/about-the-collection/governance" target="_self"><span>Governance</span></a>
                                                                                                                    </li>
                                                                                                                </ul>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/murdoch-university-art-collection/art-gallery" target="_self"><span>Art Gallery</span></a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/murdoch-university-art-collection/support-us" target="_self"><span>Support us</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/murdoch-hire-facilities" target="_self"><span>Murdoch hire facilities</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/parking"><span>Parking</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                                        <div class="nav-level" aria-label="submenu">
                                                                                            <div class="nav-list">
                                                                                                <div class="nav__title">
                                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/parking">
                                                                                                        <h3>Parking</h3>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/facilities/parking/acrod-and-easy-access-parking" target="_self"><span>ACROD and Easy Access Parking</span></a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/clubs-societies" target="_self"><span>Clubs &amp; societies</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/sport-recreation"><span>Sports &amp; recreation</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/sport-recreation">
                                                                                        <h3>Sports &amp; recreation</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/sport-recreation/murdoch-running-club" target="_self"><span>Murdoch Running Club</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/orientation" target="_self"><span>Orientation</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/security" target="_self"><span>Security</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/smoke-free-campuses" target="_self"><span>Smoke-free campuses</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/be-a-vip-at-perth-arena" target="_self"><span>Be a VIP at Perth Arena</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/support-services"><span>Support services</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/support-services">
                                                                        <h3>Support services</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/support-services/student-learning" target="_self"><span>Student learning</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/support-services/teaching-facilities" target="_self"><span>Teaching facilities</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/support-services/library-services" target="_self"><span>Library services</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/accommodation" target="_self"><span>Accommodation</span></a>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus"><span>Perth campus</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus">
                                                                        <h3>Perth campus</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/getting-here"><span>Getting here</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/getting-here">
                                                                                        <h3>Getting here</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/getting-here/parking-at-perth" target="_self"><span>Parking at Perth</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/getting-here/maps" target="_self"><span>Maps</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/emergencies" target="_self"><span>Emergencies</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/security" target="_self"><span>Security</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services"><span>Facilities &amp; services</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services">
                                                                                        <h3>Facilities &amp; services</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/library" target="_self"><span>Library</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/launchpad" target="_self"><span>Launchpad</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/student-hub" target="_self"><span>Student Hub</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/bookshop" target="_self"><span>Bookshop</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/sports-recreation" target="_self"><span>Sports &amp; recreation</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/health-counselling" target="_self"><span>Health &amp; Counselling</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/careers-centre" target="_self"><span>Careers Centre</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/child-care-centre" target="_self"><span>Child Care Centre</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/veterinary-services" target="_self"><span>Veterinary services</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/kulbardi-aboriginal-centre" target="_self"><span>Kulbardi Aboriginal Centre</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/hire-facilities" target="_self"><span>Hire facilities</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/facilities-services/worship-centre" target="_self"><span>Worship Centre</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/our-changing-campus"><span>Our changing campus</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/our-changing-campus">
                                                                                        <h3>Our changing campus</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus/our-changing-campus/master-plan" target="_self"><span>Masterplan</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/mandurah-campus"><span>Mandurah campus</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/mandurah-campus">
                                                                        <h3>Mandurah campus</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/mandurah-campus/getting-here"><span>Getting here</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/mandurah-campus/getting-here">
                                                                                        <h3>Getting here</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/mandurah-campus/getting-here/parking-at-mandurah" target="_self"><span>Parking at Mandurah</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/mandurah-campus/getting-here/maps" target="_self"><span>Maps</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/mandurah-campus/emergencies" target="_self"><span>Emergencies</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/mandurah-campus/security" target="_self"><span>Security</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/mandurah-campus/facilities-services" target="_self"><span>Facilities &amp; services</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/rockingham-campus"><span>Rockingham campus</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/rockingham-campus">
                                                                        <h3>Rockingham campus</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/rockingham-campus/getting-here"><span>Getting here</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                                        <div class="nav-level" aria-label="submenu">
                                                                            <div class="nav-list">
                                                                                <div class="nav__title">
                                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/rockingham-campus/getting-here">
                                                                                        <h3>Getting here</h3>
                                                                                    </a>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/rockingham-campus/getting-here/parking-at-rockingham" target="_self"><span>Parking at Rockingham</span></a>
                                                                                    </li>
                                                                                    <li>
                                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/rockingham-campus/getting-here/maps" target="_self"><span>Maps</span></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/international-campuses"><span>International campuses</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/international-campuses">
                                                                        <h3>International campuses</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/international-campuses/dubai" target="_self"><span>Dubai</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/international-campuses/singapore" target="_self"><span>Singapore</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/life-at-murdoch/maps-and-tours" target="_self"><span>Maps and tours</span></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-button" href="https://www.murdoch.edu.au/research-capabilities" target="_self"><span>Research</span></a>
                                    </li>
                                    <li>
                                        <a class="nav-button" href="https://www.murdoch.edu.au/industry-and-community" target="_self"><span>Industry &amp; Community</span></a>
                                    </li>
                                    <li>
                                        <a class="nav-button" href="https://www.murdoch.edu.au/alumni-and-giving" target="_self"><span>Alumni &amp; Giving</span></a>
                                    </li>
                                    <li>
                                        <a class="nav-button" href="https://www.murdoch.edu.au/about-us"><span>About Us</span></a>
                                        <button>Open submenu</button>
                                        <div class="nav-level" aria-label="submenu">
                                            <div class="nav-list">
                                                <div class="nav__title">
                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                    <a href="https://www.murdoch.edu.au/about-us">
                                                        <h3>About Us</h3>
                                                    </a>
                                                </div>
                                                <ul>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/about-us/our-history"><span>Our history</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/about-us/our-history">
                                                                        <h3>Our history</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/about-us/our-history/sir-walter-murdoch" target="_self"><span>Sir Walter Murdoch</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/about-us/locations" target="_self"><span>Locations</span></a>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/about-us/our-strategy" target="_self"><span>Our strategy</span></a>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/about-us/learning-and-teaching"><span>Learning and Teaching</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/about-us/learning-and-teaching">
                                                                        <h3>Learning and Teaching</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/about-us/learning-and-teaching/our-schools" target="_self"><span>Our schools</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/about-us/governance"><span>Governance</span></a><button aria-haspopup="true" aria-label="Open submenu">Open submenu</button>
                                                        <div class="nav-level" aria-label="submenu">
                                                            <div class="nav-list">
                                                                <div class="nav__title">
                                                                    <button class="nav-link nav-link--back" aria-label="Close submenu">Close submenu</button>
                                                                    <a href="https://www.murdoch.edu.au/about-us/governance">
                                                                        <h3>Governance</h3>
                                                                    </a>
                                                                </div>
                                                                <ul>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/about-us/governance/organisational-structure" target="_self"><span>Organisational structure</span></a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="https://www.murdoch.edu.au/about-us/governance/annual-reports" target="_self"><span>Annual reports</span></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/About-us/Careers-at-Murdoch/" target="_self"><span>Work at Murdoch</span></a>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.murdoch.edu.au/about-us/giving-to-murdoch" target="_self"><span>Giving to Murdoch</span></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <ul class="nav-links">
                                            <li>
                                                <a href="http://our.murdoch.edu.au/Students/" class="nav-btn nav-btn--fa-r link--fa-r nav-btn--external-link" target="_blank"><span>Current Students</span></a>
                                            </li>
                                            <li>
                                                <a target="_blank" class="nav-btn nav-btn--fa-r link--fa-r nav-btn--external-link" href="http://our.murdoch.edu.au/Staff/"><span>Staff</span></a>
                                            </li>
                                            <li>
                                                <a class="nav-btn nav-btn--fa-r" href="http://www.murdoch.edu.au/contact-us/"><span>Contact us</span></a>
                                            </li>
                                            <li>
                                                <a href="https://www.murdoch.edu.au/global" class="nav-btn nav-btn--fa-r"><span>Global</span></a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>-->
<main id="main" class="main" data-init-student-origin="domestic" data-init-semester="semester2" style="background-color: #000;">
                 <div class="content" >
