function myFunction(){
		 var x = document.getElementById("selectBox").value;
		table  = "<caption>---Unit Details---</caption>" +
			"<tr>" +
			"<th>UnitCode</th>" +
			"<th>" +x +"</th>" +
			"</tr>"	;
		if(x == "UnitContent"){
		table +=
			"<tr>" +
			"<td>" +unitCode[0] +"</td>" +
			"<td>"  +content +"</td>" +
			"</tr>"	;
		}

		if(x == "LearningOutcome"){
		table +=
			"<tr>" +
			"<td>"+ unitCode[0] +"</td>" +
			"<td>" +learningOutcome  +"</td>" +
			"</tr>"	;
		}
		
		if(x == "Assessment"){
		table +=
			"<tr>" +
			"<td>"+ unitCode[0] +"</td>" +
			"<td>" +assessment +"</td>" +
			"</tr>"	;
		}



  document.getElementById("UnitDetails").innerHTML = table;
   }