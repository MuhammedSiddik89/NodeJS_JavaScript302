
function initJquery(){
    var powerUsageSum = 0;
   
    for (var i = 0; i < $(document.getElementsByClassName('power_info' + (5))).length; i++)
        powerUsageSum += Number($(document.getElementsByClassName('power_info' + (5))[i]).find('usage').html());

    for (var i = 0; i < $(document.getElementsByClassName('power_info' + (6))).length; i++)
        powerUsageSum += Number($(document.getElementsByClassName('power_info' + (6))[i]).find('usage').html());
    
    for (var i = 0; i < $(document.getElementsByClassName('power_info' + (8))).length; i++)
        powerUsageSum += Number($(document.getElementsByClassName('power_info' + (8))[i]).find('usage').html());

    for (var i = 0; i < $(document.getElementsByClassName('power_info' + (9))).length; i++)
        powerUsageSum += Number($(document.getElementsByClassName('power_info' + (9))[i]).find('usage').html());

    for (var i = 0; i < $(document.getElementsByClassName('power_info' + (7))).length; i++)
        powerUsageSum += Number($(document.getElementsByClassName('power_info' + (7))[i]).find('usage').html());


    var totalmiles = powerUsageSum * 0.62;
    totalmiles /= 1.59;
    totalmiles /= 10;
    totalmiles *= 100;

    $('#amnt_co2').html((powerUsageSum * 0.62).toFixed(2));

    $('#amnt_house').html((powerUsageSum / 16.49).toFixed(2));
   
    $('#amnt_miles').html((totalmiles).toFixed(2));

    $('#amnt_light').html((1000 *powerUsageSum / 60).toFixed(0));
}


$(window).on("load", function(){
    //setup jquery stuff
    initJquery();
});