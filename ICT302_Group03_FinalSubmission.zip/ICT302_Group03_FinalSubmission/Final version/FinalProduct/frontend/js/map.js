
var map;

function initMap(){
	map = new google.maps.Map(document.getElementById('map'), {
		center: {lat: -32.067186, lng: 115.835947},
		zoom: 18,
		mapTypeId: 'satellite'
	  });
	   marker = new google.maps.Marker({
		  map: map,
		  position: new google.maps.LatLng(-32.066763, 115.836770)
	  });
	  
	  infowindow = new google.maps.InfoWindow({
		  content: '<strong>Building 245</strong><br><a href="./widget.php">View Power Usage</a>'
	  });
	  
	  google.maps.event.addListener(marker, 'click', function() {
		  infowindow.open(map, marker);
	  });
	  
	  infowindow.open(map, marker);
}
