open = $(".first");

$(".first").hover(function() {
    open.find(".subtitle").addClass("hidden");
    open.removeClass("open");
    open.find(".accordian_content").hide();

    open = $(this);

    open.find(".subtitle").removeClass("hidden");
    open.addClass("open");
    open.find(".accordian_content").show();
});

$(".second").hover(function() {
    open.find(".subtitle").addClass("hidden");
    open.removeClass("open");
    open.find(".accordian_content").hide();

    open = $(this);

    open.find(".subtitle").removeClass("hidden");
    open.addClass("open");
    open.find(".accordian_content").show();
});

$(".third").hover(function() {
    open.find(".subtitle").addClass("hidden");
    open.removeClass("open");
    open.find(".accordian_content").hide();

    open = $(this);

    open.find(".subtitle").removeClass("hidden");
    open.addClass("open");
    open.find(".accordian_content").show();
});

$(document).ready(function(){
    open.find(".subtitle").removeClass("hidden");
    open.addClass("open");
    open.find(".accordian_content").show();
});

$(".ungoal").hover(
    function(e) {
        e.preventDefault();
        $("#UNpopUp").css({
            top: e.pageY - $("#UNpopUp").height() * 2,
            left: e.pageX - ($("#UNpopUp").width() + 20)
        });

		parent = $(this).parent().parent();

        var newsLink = parent.find(".hiddenLinkNews").html();
        //$("#News").html(newsLink);
        var actionLink = parent.find(".hiddenLinkAction").html();
        //$("#Action").html(actionLink);
        var curriculumLink = parent.find(".hiddenLinkCurriculum").html();
        //$("#Curriculum").html(curriculumLink);
        var researchLink = parent.find(".hiddenLinkResearch").html();
        //$("#Research").html(researchLink);
        var rLink = parent.find(".hiddenLinkRsrc").html();
        //$("#ExternalResources").html(rLink);

        $(this).find('.un_goal_menu').html(newsLink + actionLink + curriculumLink + researchLink + rLink);
        $(this).find('.w_h_100').hide();
        //console.log($(this).find('w_h_100').html())

        //$('#UNpopUp').clearQueue().fadeIn(100);
    },
    function(e) {
        //$('#UNpopUp').delay(200).hide();
        $(this).find('.un_goal_menu').html("");
        $(this).find('.w_h_100').show();
    }
);

$("#UNpopUp").hover(
    function(e) {
        e.preventDefault();
        $("#UNpopUp").css("opacity", 1)
        $("UNpopUp").show();
        $("#UNpopUp").clearQueue().delay(300).show();
    },
    function(e) {
        $('#UNpopUp').delay(200).fadeOut();
    }
);
