
var myChart;

function setChartData(power_list, chart, color){
    chart.data.labels = [];
    chart.data.datasets[0].data = [];

    for (var i = 0; i < power_list.length; i++){
        chart.data.datasets[0].data.push($(power_list[i]).find('usage').html());
        chart.data.labels.push($(power_list[i]).find('date').html());
    }

    chart.data.datasets[0].backgroundColor = color;

    chart.update();
}

/**
 * Initalises the jquery callbacks found on the page, including:
 *      + Power info modal display
 *      + "how the use the site" modal display
 *      + Disabling click event for image map
 */
function initJquery() {
    

    $(".building_zone_power_3").hover(
        function(e) {
            e.preventDefault();

            var item1p = document.getElementsByClassName('power_info' + 6);

            $("#widget_heading").html("Level 3 | Building 245");

            $("#widget_zone").html("Lights Meter | Zone 1 | Robertson Lecture Theater");

            $("#widget_power_type").html("Energy Use (Kwh)")

            setChartData(item1p, myChart, "#83133D");
            $("#power_usage_modal").css({
                top: e.pageY - $("#power_usage_modal").height()/2- 130,
                left: e.pageX - ($("#power_usage_modal").width() + 80)
            });
            $('#power_usage_modal').show();
        }, 
        function(e) {
            $('#power_usage_modal').hide();
        }
    );

    $(".building_zone_lights_3").hover(
        function(e) {
            e.preventDefault();

            var item1p = document.getElementsByClassName('power_info' + 5);

            $("#widget_heading").html("Level 3 | Building 245");

            $("#widget_zone").html("Power Meter | Zone 1 | Robertson Lecture Theater");

            $("#widget_power_type").html("Energy Use (Kwh)")

            setChartData(item1p, myChart, "#83133D");
            $("#power_usage_modal").css({
                top: e.pageY - $("#power_usage_modal").height()/2- 130,
                left: e.pageX - ($("#power_usage_modal").width() + 80)
            });
            $('#power_usage_modal').show();
        }, 
        function(e) {
            $('#power_usage_modal').hide();
        }
    );

    $(".building_zone_cooling_3").hover(
        function(e) {
            e.preventDefault();

            var item1p = document.getElementsByClassName('power_info' + 10);

            $("#widget_heading").html("Level 3 | Building 245");

            $("#widget_zone").html("Cooling Meter | Zone 2 | Server Room");

            $("#widget_power_type").html("Server Temperature (Degrees Celcius)")

            setChartData(item1p, myChart, "#FFF60D");
            $("#power_usage_modal").css({
                top: e.pageY - $("#power_usage_modal").height()/2- 130,
                left: e.pageX - ($("#power_usage_modal").width() + 80)
            });
            $('#power_usage_modal').show();
        }, 
        function(e) {
            $('#power_usage_modal').hide();
        }
    );

    $(".building_zone_lights_3_2").hover(
        function(e) {
            e.preventDefault();

            var item1p = document.getElementsByClassName('power_info' + 8);

            $("#widget_heading").html("Level 3 | Building 245");

            $("#widget_zone").html("Lights Meter | Zone 3");

            $("#widget_power_type").html("Energy Use (Kwh)")

            setChartData(item1p, myChart, "#7AFFFF");
            $("#power_usage_modal").css({
                top: e.pageY - $("#power_usage_modal").height()/2- 130,
                left: e.pageX - ($("#power_usage_modal").width() + 80)
            });
            $('#power_usage_modal').show();
        }, 
        function(e) {
            $('#power_usage_modal').hide();
        }
    );

    $(".building_zone_power_3_2").hover(
        function(e) {
            e.preventDefault();

            var item1p = document.getElementsByClassName('power_info' + 9);

            $("#widget_heading").html("Level 3 | Building 245");

            $("#widget_zone").html("Power Meter | Zone 3");

            $("#widget_power_type").html("Energy Use (Kwh)")

            setChartData(item1p, myChart, "#7AFFFF");
            $("#power_usage_modal").css({
                top: e.pageY - $("#power_usage_modal").height()/2- 130,
                left: e.pageX - ($("#power_usage_modal").width() + 80)
            });
            $('#power_usage_modal').show();
        }, 
        function(e) {
            $('#power_usage_modal').hide();
        }
    );

    $(".building_zone_power_3_3").hover(
        function(e) {
            e.preventDefault();

            var item1p = document.getElementsByClassName('power_info' + 6);

            $("#widget_heading").html("Level 2 | Building 245");

            $("#widget_zone").html("Lights Meter | Zone 1 | Robertson Lecture Theater");

            $("#widget_power_type").html("Energy Use (Kwh)")

            setChartData(item1p, myChart, "#83133D");
            $("#power_usage_modal").css({
                top: e.pageY - $("#power_usage_modal").height()/2- 130,
                left: e.pageX - ($("#power_usage_modal").width() + 80)
            });
            $('#power_usage_modal').show();
        }, 
        function(e) {
            $('#power_usage_modal').hide();
        }
    );

    $(".building_zone_lights_3_3").hover(
        function(e) {
            e.preventDefault();

            var item1p = document.getElementsByClassName('power_info' + 5);

            $("#widget_heading").html("Level 2 | Building 245");

            $("#widget_zone").html("Power Meter | Zone 1 | Robertson Lecture Theater");

            $("#widget_power_type").html("Energy Use (Kwh)")

            setChartData(item1p, myChart, "#83133D");
            $("#power_usage_modal").css({
                top: e.pageY - $("#power_usage_modal").height()/2- 130,
                left: e.pageX - ($("#power_usage_modal").width() + 80)
            });
            $('#power_usage_modal').show();
        }, 
        function(e) {
            $('#power_usage_modal').hide();
        }
    );

    $(".building_zone_power_3_4").hover(
        function(e) {
            e.preventDefault();

            var item1p = document.getElementsByClassName('power_info' + 7);

            $("#widget_heading").html("Level 3 | Building 245");

            $("#widget_zone").html("Power Meter | Zone 3 | Server Room");

            $("#widget_power_type").html("Energy Use (Kwh)")

            setChartData(item1p, myChart, "#FFF60D");
            $("#power_usage_modal").css({
                top: e.pageY - $("#power_usage_modal").height()/2- 130,
                left: e.pageX - ($("#power_usage_modal").width() + 80)
            });
            $('#power_usage_modal').show();
        }, 
        function(e) {
            $('#power_usage_modal').hide();
        }
    );

    $('.building_zone').click(
        function(event) {
            event.preventDefault();
            return false;
        }
    );

    $('.cross_sect').click(
        function(event) {
            $('#power_view').fadeIn();
        }
    );

    $("#info_anchor").hover(
        function(e) {
            e.preventDefault();
            $("#cross_sect").css({
                bottom: e.pageY - $("#circle_box").height() * 2,
                left: e.pageX - ($("#circle_box").width() + 40)
            });
            $('#circle_box').fadeIn();
        },
        function(e) {
            $('#circle_box').fadeOut();
        }
    );

    $(".cross_sect").hover(
        function(e) {
            $("#cross_section_Level1").animate({
                bottom: "-30px"
            });

            $("#cross_section_Level2").animate({
                bottom: "-10px"
            });

            $("#cross_section_Level3").animate({
                bottom: "10px"
            });

            $("#cross_section_Level4").animate({
                bottom: "30px"
            });

            $("#view_building").animate({
                opacity:"1"
            });
        },
        function() {
            $("#cross_section_Level1").clearQueue().animate({
                bottom: "0"
            });

            $("#cross_section_Level2").clearQueue().animate({
                bottom: "0"
            });

            $("#cross_section_Level3").clearQueue().animate({
                bottom: "0"
            });

            $("#cross_section_Level4").clearQueue().animate({
                bottom: "0"
            });

            $("#view_building").clearQueue().animate({
                opacity:"0"
            });
        }
    );

	$('#hide_power_view').click(
		function(){
			$('#power_view').fadeOut();
		}
	);

	var active = '#bimg_1';

	$('#show_lvl_1').click(
		function(){
			if(active === '#bimg_1') return;

			$(active).hide()

			active = '#bimg_1';
			
			$(active).fadeIn();
		}
	);
	$('#show_lvl_2').click(
		function(){
			if(active === '#bimg_2') return;

			$(active).hide()

			active = '#bimg_2';

			$(active).fadeIn();

			$('map').imageMapResize();
		}
	);
	$('#show_lvl_3').click(
		function(){
			if(active === '#bimg_3') return;

			$(active).hide()

			active = '#bimg_3';

			$(active).fadeIn();

			$('map').imageMapResize();
		}
	);

    var powerUsageSum = 0;
   
    for (var i = 0; i < $(document.getElementsByClassName('power_info' + (5))).length; i++)
        powerUsageSum += Number($(document.getElementsByClassName('power_info' + (5))[i]).find('usage').html());

    for (var i = 0; i < $(document.getElementsByClassName('power_info' + (6))).length; i++)
        powerUsageSum += Number($(document.getElementsByClassName('power_info' + (6))[i]).find('usage').html());
    
    for (var i = 0; i < $(document.getElementsByClassName('power_info' + (8))).length; i++)
        powerUsageSum += Number($(document.getElementsByClassName('power_info' + (8))[i]).find('usage').html());

    for (var i = 0; i < $(document.getElementsByClassName('power_info' + (9))).length; i++)
        powerUsageSum += Number($(document.getElementsByClassName('power_info' + (9))[i]).find('usage').html());

        for (var i = 0; i < $(document.getElementsByClassName('power_info' + (7))).length; i++)
        powerUsageSum += Number($(document.getElementsByClassName('power_info' + (7))[i]).find('usage').html());


    $('#building_Power_Usage').html(powerUsageSum.toFixed(0) + " Kwh");


    $("area").click(function(){ return false});
}

/**
 * Sets up chart js object.
 */
function initMap() {
    var ctx = document.getElementById("myChart").getContext('2d');
    myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["12.30PM", "1.00PM", "1.30PM", "2.00PM", "3.00PM", "3.30PM", "12.30PM", "1.00PM", "1.30PM", "2.00PM", "3.00PM", "3.30PM"],
            datasets: [{
                label: 'Power Demand in Kwh',
                data: [2.3, 3.2, 3, 2.2, 2, 3, 4.2, 3, 2.8, 3.2, 2, 3],
                backgroundColor: '#83133D',
                borderColor: 'rgba(0,0,0)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    },

                    gridLines: {
                        color: "rgba(0, 0, 0, 0)"
                    }
                }],
                xAxes: [{
                    ticks: {
                        minRotation: 90
                    },

                    gridLines: {
                        color: "rgba(0, 0, 0, 0)"
                    }
                }],

            },
            legend: {
                display: false,
                labels: {
                    fontColor: "#FF0000",
                }
            }
        }
    });
}

function initWeather(){
    $.simpleWeather({
        location: 'Perth, WA',
        woeid: '',
        unit: 'c',
        success: function(weather) {
          html = '<h1>Weather</h1>'
		  html += '<h2><i class="icon-'+weather.code+'"></i> '+weather.temp+'&deg;'+weather.units.temp+'</h2>';
          html += '<ul><li>'+weather.city+', '+weather.region+'</li>';
          html += '<li class="currently">'+weather.currently+'</li>';
          html += '<li>'+weather.wind.direction+' '+weather.wind.speed+' '+weather.units.speed+'</li></ul>';
            console.log(html)
          $("#weather").html(html);
        },
        error: function(error) {
          $("#weather").html('<p>'+error+'</p>');
        }
    });

}

/**
 * initalises scripts on page load.
 */
$(window).on("load", function(){
    //Hide load screen
    $("#loading_draw_left").toggleClass("closed_left");
    $("#loading_draw_right").toggleClass("closed_right");
    $("#loading_text").fadeOut(100);

    //enable responsive image maps
    $('map').imageMapResize();

    //setup jquery stuff
    initJquery();
    initMap();
    initWeather();
});