$(document).ready(function() {

    var chartSDG = document.getElementById("chart-0");
    var chartSDG1 = document.getElementById("chart-1");
    var chartSDG2 = document.getElementById("chart-2");
    var chartSDG3 = document.getElementById("chart-3");
    var chartSDG4 = document.getElementById("chart-4");

    var myChart;
    var myChart1;
    var myChart2;
    var myChart3;
    var myChart4;

    var output;
    var mchart;
    var type;
    var table;
    var counter = 0;



    $("#a").click(function() {

        myChart = new Chart(chartSDG, {
            type: 'polarArea',
            data: {
                labels: goal_name,
                datasets: [{
                    label: "SDGs",
                    data: hits,
                    backgroundColor: ["rgba(128, 0, 0, .7)", "rgba(170, 110, 40, .7)", "rgba(0, 128, 128, .7)", "rgba(245, 130, 48, .7)", "rgba(60, 180, 75, .7)", "rgba(0, 0, 128, .7)", "rgba(230, 25, 75, .7)", "rgba(145, 30, 180, .7)", "rgba(128, 128, 128, .7)", "rgba(212, 42, 161, .7)", "rgba(210, 245, 60, .7)", "rgba(70, 240, 240, .7)", "rgba(230, 190, 255, .7)", "rgba(255, 215, 180, .7)", "rgba(0, 130, 200, .7)", "rgba(250, 190, 190, .7)", "rgba(170, 255, 195, .7)"],
                    borderWidth: 2
                }]
            },
            options: {
                plugins: {
                    labels: {
                        render: 'value'
                    }
                },
                tooltips: {
                    callbacks: {
                        label: function(tooltipItem, data) {
                            var allData = data.datasets[tooltipItem.datasetIndex].data;
                            var tooltipLabel = data.labels[tooltipItem.index];
                            var tooltipData = allData[tooltipItem.index];
                            var total = 0;
                            for (var i in allData) {
                                total += allData[i];
                            }
                            var tooltipPercentage = ((tooltipData / 860) * 100).toFixed(2);
                            return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';

                        }
                    }
                },

                legend: {
                    display: true,
                    position: "left"
                },
                title: {
                    display: true,
                    fontSize: 24,
                    text: '*Click SDG in legend to filter from chart*                        ' + unitCode[0] + ' SDG Hits for Year ' + year[0] + '                                                         ',
                    lineHeight: 1
                },
                layout: {
                    padding: {
                        top: 10
                    }
                }
            }

        });
        type = 'polarArea';
        pointLink(type);

    });


    $("#b").click(function() {

        myChart1 = new Chart(chartSDG1, {
            type: 'pie',
            data: {
                labels: goal_name,

                datasets: [{
                    label: "SDGs",
                    data: hits,
                    backgroundColor: ["rgba(128, 0, 0, .7)", "rgba(170, 110, 40, .7)", "rgba(0, 128, 128, .7)", "rgba(245, 130, 48, .7)", "rgba(60, 180, 75, .7)", "rgba(0, 0, 128, .7)", "rgba(230, 25, 75, .7)", "rgba(145, 30, 180, .7)", "rgba(128, 128, 128, .7)", "rgba(212, 42, 161, .7)", "rgba(210, 245, 60, .7)", "rgba(70, 240, 240, .7)", "rgba(230, 190, 255, .7)", "rgba(255, 215, 180, .7)", "rgba(0, 130, 200, .7)", "rgba(250, 190, 190, .7)", "rgba(170, 255, 195, .7)"],
                    borderWidth: 2
                }]
            },
            options: {
                tooltips: {
                    callbacks: {
                        label: function(tooltipItem, data) {
                            var allData = data.datasets[tooltipItem.datasetIndex].data;
                            var tooltipLabel = data.labels[tooltipItem.index];
                            var tooltipData = allData[tooltipItem.index];
                            var total = 0;
                            for (var i in allData) {
                                total += allData[i];
                            }
                            var tooltipPercentage = ((tooltipData / 860) * 100).toFixed(2);
                            return tooltipLabel + ': ' + tooltipData + ' (' + tooltipPercentage + '%)';
                        }
                    }
                },
                legend: {
                    fontColor: 'rgb(255, 99, 132)',
                    display: true,
                    position: "left"
                },
                title: {
                    display: true,
                    fontSize: 24,
                    text: '*Click SDG in legend to filter from chart*                        ' + unitCode[0] + ' SDG Hits for Year ' + year[0] + '                                                         ',
                    lineHeight: 1
                }

            }

        });
        type = 'pie';
        pointLink(type);

    });

    $("#c").click(function() {

        myChart2 = new Chart(chartSDG2, {
            type: 'radar',
            data: {

                labels: goal_name,

                datasets: [{
                    label: "SDGs",
                    data: hits,
                    backgroundColor: "rgb(0,0,0,.7)",
                    pointBackgroundColor: ["rgba(128, 0, 0, .7)", "rgba(170, 110, 40, .7)", "rgba(0, 128, 128, .7)", "rgba(245, 130, 48, .7)", "rgba(60, 180, 75, .7)", "rgba(0, 0, 128, .7)", "rgba(230, 25, 75, .7)", "rgba(145, 30, 180, .7)", "rgba(128, 128, 128, .7)", "rgba(212, 42, 161, .7)", "rgba(210, 245, 60, .7)", "rgba(70, 240, 240, .7)", "rgba(230, 190, 255, .7)", "rgba(255, 215, 180, .7)", "rgba(0, 130, 200, .7)", "rgba(250, 190, 190, .7)", "rgba(170, 255, 195, .7)"],
                    pointLabelFontSize: 24,
                    borderWidth: 2,
                    pointRadius: 4

                }]
            },
            options: {
                scale: {
                    scaleLabel: {
                        display: true,
                        labelString: "Percentage"
                    },
                    pointLabels: {
                        fontSize: 20,
                        fontColor: ["rgba(128, 0, 0)", "rgba(170, 110, 40)", "rgba(0, 128, 128)", "rgba(245, 130, 48)", "rgba(60, 180, 75)", "rgba(0, 0, 128)", "rgba(230, 25, 75)", "rgba(145, 30, 180)", "rgba(128, 128, 128)", "rgba(212, 42, 161)", "rgba(210, 245, 60)", "rgba(70, 240, 240)", "rgba(230, 190, 255)", "rgba(255, 215, 180)", "rgba(0, 130, 200)", "rgba(250, 190, 190)", "rgba(170, 255, 195)"]
                    },
                },
                legend: {
                    fontSize: 24,
                    display: false,
                    position: "left"
                },
                title: {
                    display: true,
                    fontSize: 24,
                    text: unitCode[0] + ' SDG Hits for Year ' + year[0],
                    lineHeight: 1
                }
            }
        });
        type = 'radar';
        pointLink(type);

    });

    $("#d").click(function() {

        myChart3 = new Chart(chartSDG3, {
            type: 'line',
            data: {
                labels: goal_name,
                datasets: [{
                    label: "SDGs",
                    data: hits,
                    backgroundColor: window.chartColors.white,
                    borderColor: ["rgba(128, 0, 0, .7)", "rgba(170, 110, 40, .7)", "rgba(0, 128, 128, .7)", "rgba(245, 130, 48, .7)", "rgba(60, 180, 75, .7)", "rgba(0, 0, 128, .7)", "rgba(230, 25, 75, .7)", "rgba(145, 30, 180, .7)", "rgba(128, 128, 128, .7)", "rgba(227, 235, 210, .7)", "rgba(210, 245, 60, .7)", "rgba(70, 240, 240, .7)", "rgba(230, 190, 255, .7)", "rgba(255, 215, 180, .7)", "rgba(0, 130, 200, .7)", "rgba(250, 190, 190, .7)", "rgba(170, 255, 195, .7)"],
                    borderWidth: 2,
                    pointBackgroundColor: ["rgba(128, 0, 0, .7)", "rgba(170, 110, 40, .7)", "rgba(0, 128, 128, .7)", "rgba(245, 130, 48, .7)", "rgba(60, 180, 75, .7)", "rgba(0, 0, 128, .7)", "rgba(230, 25, 75, .7)", "rgba(145, 30, 180, .7)", "rgba(128, 128, 128, .7)", "rgba(212, 42, 161, .7)", "rgba(210, 245, 60, .7)", "rgba(70, 240, 240, .7)", "rgba(230, 190, 255, .7)", "rgba(255, 215, 180, .7)", "rgba(0, 130, 200, .7)", "rgba(250, 190, 190, .7)", "rgba(170, 255, 195, .7)"]

                }]
            },
            options: {
                tooltips: {
                    mode: 'point'
                },
                scaleShowValues: true,
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }],
                    xAxes: [{
                        ticks: {
                            autoSkip: false
                        }
                    }]
                },

                legend: {

                    display: false,
                    position: "top"
                },
                title: {
                    display: true,
                    fontSize: 24,
                    text: unitCode[0] + ' SDG Hits for Year ' + year[0],
                    lineHeight: 3
                }
            }
        });
        type = 'line';
        pointLink(type);

    });

    $("#e").click(function() {

        myChart4 = new Chart(chartSDG4, {
            type: 'bar',
            data: {
                labels: goal_name,
                datasets: [{
                    label: "SDGs",
                    data: hits,
                    backgroundColor: ["rgba(128, 0, 0, .7)", "rgba(170, 110, 40, .7)", "rgba(0, 128, 128, .7)", "rgba(245, 130, 48, .7)", "rgba(60, 180, 75, .7)", "rgba(0, 0, 128, .7)", "rgba(230, 25, 75, .7)", "rgba(145, 30, 180, .7)", "rgba(128, 128, 128, .7)", "rgba(212, 42, 161, .7)", "rgba(210, 245, 60, .7)", "rgba(70, 240, 240, .7)", "rgba(230, 190, 255, .7)", "rgba(255, 215, 180, .7)", "rgba(0, 130, 200, .7)", "rgba(250, 190, 190, .7)", "rgba(170, 255, 195, .7)"],
                    borderWidth: 2

                }]
            },
            options: {
                plugins: {
                    labels: {
                        render: 'value'
                    }
                },
                scaleShowValues: true,
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }],
                    xAxes: [{

                        fontSize: 24,
                        ticks: {
                            autoSkip: false
                        }
                    }]
                },
                legend: {
                    display: false,
                    position: "left"
                },
                title: {
                    display: true,
                    fontSize: 24,
                    text: unitCode[0] + ' SDG Hits for Year ' + year[0],
                    lineHeight: 3
                }
            }
        });

        type = 'bar';
        pointLink(type);

    });

    function pointLink(type) {

        if (type == 'polarArea') {
            output = chartSDG;
            mchart = myChart;
        } else if (type == 'pie') {
            output = chartSDG1;
            mchart = myChart1;

        } else if (type == 'radar') {
            output = chartSDG2;
            mchart = myChart2;

        } else if (type == 'line') {
            output = chartSDG3;
            mchart = myChart3;

        } else if (type == 'bar') {
            output = chartSDG4;
            mchart = myChart4;
        }


        output.onclick = function(evt) {

            var activePoints = mchart.getElementsAtEvent(evt);
            var chartData = activePoints[0]['_chart'].config.data;
            var idx = activePoints[0]['_index'];
            var label = chartData.labels[idx];

            //The below links will not work currently as the createTable function is not included
            //Waiting for client feedback on the graphs then will code the link back to the 1st/2nd level once finalised as the graphs may be removed completely if the client doesn't want them
            //Also the graph code above for each graph type will need to be updated as the graph code in curriculum.php has been updated since unit.php was originally made (eg. the location of the hit counts and the percentage on the polar area graph)
            if (label == goal_name[0]) {
                createTable(goal_name[0]);
            } else if (label == goal_name[1]) {
                createTable(goal_name[1]);
            } else if (label == goal_name[2]) {
                createTable(goal_name[2]);
            } else if (label == goal_name[3]) {
                createTable(goal_name[3]);
            } else if (label == goal_name[4]) {
                createTable(goal_name[4]);
            } else if (label == goal_name[5]) {
                createTable(goal_name[5]);
            } else if (label == goal_name[6]) {
                createTable(goal_name[6]);
            } else if (label == goal_name[7]) {
                createTable(goal_name[7]);
            } else if (label == goal_name[8]) {
                createTable(goal_name[8]);
            } else if (label == goal_name[9]) {
                createTable(goal_name[9]);
            } else if (label == goal_name[10]) {
                createTable(goal_name[10]);
            } else if (label == goal_name[11]) {
                createTable(goal_name[11]);
            } else if (label == goal_name[12]) {
                createTable(goal_name[12]);
            } else if (label == goal_name[13]) {
                createTable(goal_name[13]);
            } else if (label == goal_name[14]) {
                createTable(goal_name1[14]);
            } else if (label == goal_name[15]) {
                createTable(goal_name[15]);
            } else if (label == goal_name[16]) {
                createTable(goal_name[16]);
            }

        };
    }

    if (searchUnit != "") {
        counter = 0;
        unittable = "<caption>" + unitCode[0] + " - " + unitTitle[0] + "</caption>" +
            "<tr>" +
            "<th>SDG</th>" +
            "<th>Hit on Unit Content?</th>" +
            "<th>Hit on Learning Outcome?</th>" +
            "<th>Hit on Assessment?</th>" +
            "</tr>";

        for (var i = 0; i < hitOnSection.length; i++) {

            if (unitCode[i] == searchUnit) {

                unittable += "<tr>" +
                    "<td>" + goal_name[i] + "</td>";

                var regWord1 = 'Content';
                var reg1 = new RegExp('\\b' + regWord1 + '\\b');

                if (reg1.test(hitOnSection[i])) {
                    unittable += "<td><span>&#10003;</span></td>";
                } else {
                    unittable += "<td><span>&#032;</span></td>";
                }

                var regWord2 = 'Learning';
                var reg2 = new RegExp('\\b' + regWord2 + '\\b');

                if (reg2.test(hitOnSection[i])) {
                    unittable += "<td><span>&#10003;</span></td>";
                } else {
                    unittable += "<td><span>&#032;</span></td>";
                }

                var regWord3 = 'Assessment';
                var reg3 = new RegExp('\\b' + regWord3 + '\\b');

                if (reg3.test(hitOnSection[i])) {
                    unittable += "<td><span>&#10003;</span></td>";
                } else {
                    unittable += "<td><span>&#032;</span></td>";
                }

                unittable += "</tr>";
                counter++;
            }
        }

        unittable += "<tr>" +
            "<td>" + "Total SDGs Achieved: " + "</td>" +
            "<td>" + " " + counter + " " + "</td>" +
            "</tr>";


        if (counter == 0) {

            unittable += "<div>" +
                "<h1>Their are no goals hit for this unit</h1>" +
                "</div>";
        }
        document.getElementById("SDGHitDescTable").innerHTML = unittable;
    }


});
