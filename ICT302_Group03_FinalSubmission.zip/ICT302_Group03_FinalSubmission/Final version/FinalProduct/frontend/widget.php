<?php
	require "./Header.php";
?>
<div class="widget_container">
	<div class="content_box_100">
		<div class="title_contraints">
			<h1 class="heading_jumbo">
				<b>Building 245</b>
			</h1>
			<div class="power_total">
				<div class="center_vertical_hack">
					<div class="vertical_hack_pt2">
						<h2 id="building_Power_Usage" class="white_heading">45 kWh</h2>
					</div>
				</div>
			</div>
			<h2 class="subheading_light">
				 Total Power Usage in the Last 24 Hours
			</h2>
			<!-- <img id="info_anchor" alt="Question Mark" src="./img/question.svg" width="50" height="50" /> -->
		</div>
		<div id = "weather">
		</div>
		<div class="content_box">
			<div class="building_display">
			</div>
		</div>

		<div class="building">
			<img  id = "cross_section_Level1" class="cross_sect" alt="Building Cross Sections" src = "./img/B245SVG/B245Level1.svg" usemap="#image-map"/>
			<img  id = "cross_section_Level2" class="cross_sect" alt="Building Cross Sections" src = "./img/B245SVG/B245Level2.svg" usemap="#image-map"/>
			<img  id = "cross_section_Level3" class="cross_sect" alt="Building Cross Sections" src = "./img/B245SVG/B245Level3.svg" usemap="#image-map"/>
			<img  id = "cross_section_Level4" class="cross_sect" alt="Building Cross Sections" src = "./img/B245SVG/B245Roof.svg" usemap="#image-map"/>
			<div id="view_building">
				<button class="look_inside_button">Look Inside</button>
			</div>
		</div>

		<div id="cloud">
		</div>
		<div id="cloud_2">
		</div>
		<div id="sun">
			<div id="rings">
				<div></div>
				<div></div>
				<div></div>
				<div></div>
			</div>
		</div>
		<div id="bottom_tree">
			<div id="buttonCarousel">
				<a class="btninfo" href="carousel.php" >More info</a>
			</div>
		</div>
	</div>



	<div id = "find_out_more">
		<div class="content_box">
			<a class="btninfo" href="carousel.php" >More info</a>
		</div>
	</div>
    <div class="overflow_container">
        <div id="loading_draw_left" class="transition_left">
        </div>
        <div id="loading_draw_right" class="transition_right">
        </div>
        <div id="loading_text">
            <!-- Embedded in HTML so available while the rest of the content loads. -->
            <svg viewBox="0 0 512 512" class="load_icon">
                <path d="m360.6 252.56c-1.201-5.068-4.922-9.141-9.858-10.781l-73.594-24.536 52.266-104.53c3.281-6.577 1.318-14.575-4.644-18.882-5.991-4.292-14.194-3.647-19.38 1.567l-150 150c-3.677 3.677-5.186 8.994-3.999 14.048 1.201 5.068 4.922 9.141 9.858 10.781l73.594 24.536-52.266 104.53c-3.281 6.577-1.318 14.575 4.644 18.882 5.971 4.279 14.158 3.653 19.38-1.567l150-150c3.677-3.677 5.186-8.994 3.999-14.048z" fill="#46821b"/>
                <path d="m256 0c-76.13 0-148.04 35.406-196 92.529v-16.529c0-8.291-6.709-15-15-15s-15 6.709-15 15v63.721c0 14.315 18.49 16.364 15 15 0.308 0 0.615-0.015 0.923-0.029l60-3.721c8.276-0.513 14.561-7.632 14.048-15.894s-7.734-14.487-15.894-14.048l-30.394 1.89c42.1-57.268 110.22-92.919 182.32-92.919 124.07 0 226 101.93 226 226 0 8.291 6.709 15 15 15s15-6.709 15-15c0-140.61-115.39-256-256-256z" fill="#46821b"/>
                <path d="m466.08 357.31l-60 3.721c-8.276 0.513-14.561 7.632-14.048 15.894s7.896 14.561 15.894 14.048l30.394-1.89c-42.1 57.268-110.22 92.919-182.32 92.919-124.07 0-226-101.93-226-226 0-8.291-6.709-15-15-15s-15 6.709-15 15c0 140.61 115.39 256 256 256 76.13 0 148.04-35.406 196-92.529v16.529c0 8.291 6.709 15 15 15s15-6.709 15-15v-63.721c0-8.24-7.901-15.423-15.923-14.971z" fill="#46821b"/>
            </svg>
        </div>
    </div>
	<div id="sky_gradient">
	</div>
	<!--<div id="bottom_grass">
	</div>-->
	<div id="bottom_grass_parralax">
	</div>
	<div id = "power_view" style="background-color:rgba(0,0,0,0.8);position:absolute;top:0;left:0;z-index:20;height:100%; width:100%;">
		<div class="content_box vertical-center">
			<div class="active_building_section" id="bimg_1">
				<img  class = "img_h_100" alt="Building Cross Sections" src = "./img/B245SVG/B245Level1.svg"/>
			</div>
			<div class="building_section" id="bimg_2">
				<img  class = "img_h_100" alt="Building Cross Sections" src = "./img/B245SVG/B245Level2Icons.png" usemap="#lvl2_map"/>
				<map name="lvl2_map">
					<area target="_blank" class="building_zone_power_3_3" alt="Light Icon" title="Light Icon" href="javascript: void(0)" coords="482,565,36" shape="circle">
					<area target="_blank" class="building_zone_lights_3_3" alt="Power Icon" title="Power Icon" href="javascript: void(0)" coords="547,604,34" shape="circle">
				</map>
			</div>
			<div class="building_section"  id="bimg_3">
				<img  class = "img_h_100" alt="Building Cross Sections" src = "./img/B245SVG/B245Level3Icons.png" usemap="#lvl3_map"/>
				<map name="lvl3_map">
					<area target="_blank" class="building_zone_power_3" alt="Light Icon" title="Light Icon" href="javascript: void(0)" coords="481,566,35" shape="circle">
					<area target="_blank" class="building_zone_lights_3" class="building_zone" alt="Power Icon" title="Power Icon" href="javascript: void(0)" coords="546,602,33" shape="circle">
					<area target="_blank" class="building_zone_cooling_3" class="building_zone" alt="Cooling Icon" title="Cooling Icon" href="javascript: void(0)" coords="989,629,37" shape="circle">
					<area target="_blank" class="building_zone_lights_3_2" class="building_zone" alt="Light Icon" title="Light Icon" href="javascript: void(0)" coords="1172,551,35" shape="circle">
					<area target="_blank" class="building_zone_power_3_2"  alt="Power Icon" title="Power Icon" href="javascript: void(0)" coords="1244,512,36" shape="circle">
					<area target=""  class="building_zone_power_3_4" alt="" title="" href="" coords="917,676,35" shape="circle">
				</map>
			</div>
			<div id="building_view_controls">
				<div class="content_box">
					<button class="red_button" id = "hide_power_view">Close <br> </button>
					<button class="red_button" id = "show_lvl_1">Level 1</button>
					<button class="red_button" id = "show_lvl_2">Level 2</button>
					<button class="red_button" id = "show_lvl_3">Level 3</button>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="power_usage_modal" class="arrow_box">
	<h2 class="heading_light" id= "widget_heading">
		Level 2 | ICT Innovation Hub
	</h2>
	<h3 class="subheading_light" id="widget_zone">
		Room 245.2.1
	</h3>
	<br \>
	<div class="power_usage_chart">
		<h3 class = "subheading_lighter padded_segment" id="widget_power_type">
			Energy Usage Chart
		</h3>
		<canvas id="myChart"></canvas>
	</div>
</div>
<?php

    require "./PHP/DBConnect.php";

    $query = "SELECT * FROM DevicePower WHERE Device='6' or Device='5' or Device='10' or Device='8' or Device='7' or Device='9' ORDER BY Recorded";
    $result = mysqli_query($con, $query);

	if (mysqli_num_rows($result) > 0)
    {
        //output data of each row
        echo '<div style="display:none;">';

        while ($row = mysqli_fetch_assoc($result))
        {
			echo "<div class = 'power_info" . $row["Device"] ."'>";
			echo "<date>" . substr($row["Recorded"], strpos($row["Recorded"], ' ')) . "</date><usage>" .$row["PowerUsageKwh"] ."</usage>";
			echo "</div>";
        }
        echo '</div>';
    }

	require "./PHP/DBClose.php";
?>

<!--
	Commented out until we find a good place to put this

	<div>Icons made by <a href="http://www.freepik.com" title="Freepik">Freepik</a>
	from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a>
	is licensed by <a href="http://creativecommons.org/licenses/by/3.0/"
	title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
    -->

<!-- Append following scripts to end of page body. -->
<!-- End of scripts. -->
<?php
	$leftButton = "./map.php";
	$rightButton = "./carousel.php";
	$scripts = array("./js/jquery-3.3.1.min.js", "./js/jquery.rwdImageMaps.min.js", "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.bundle.js", "./js/widget.js", "./js/jquery.simpleWeather.min.js");
	require "./Footer.php";
?>
