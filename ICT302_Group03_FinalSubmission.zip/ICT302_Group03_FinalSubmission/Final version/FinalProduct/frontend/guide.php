<?php
	require "./Header.php";

echo '

<CENTER><IMG SRC="./img/icons/QA.jpg" ALIGN="BOTTOM" style="width:500px;height:200px;"> </CENTER>

<HR>
<H3 align="center">FAQS</H3>


<H2>Q1. What do the charts show on curriculum page?</H2></br>
	 Ans. Curriculum page shows different types of charts that represent number of units that contribute to a specific UN set sustainable development goal.</br></br>
<H2>Q2. What do the charts show once I click on any unit?</H2></br>
	 Ans. Unit page shows charts that represent number of goals hit by that specific unit.</br></br>
<H2>Q3. What happens once clicked on a section of chart?</H2></br>
	 Ans. It shows a table that displays all the units hit on the clicked goal(section of chart) and where in the unit did that hit i.e Assesment, learning outcome or unit content.</br></br>
<H2>Q4. What does the number outside pie chart show?</H2></br>
	 Ans. It shows the number of units hitting on that goal.</br></br>
</br>';
?>
</div>


<?php
require "./Footer_curriculum.php";
?>