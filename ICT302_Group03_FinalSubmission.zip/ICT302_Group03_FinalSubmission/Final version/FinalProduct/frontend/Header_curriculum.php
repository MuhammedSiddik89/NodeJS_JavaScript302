<!DOCTYPE html>
<html class=" localstorage no-flexboxtweener" lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta charset="utf-8">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto+Slab" rel="stylesheet">
        <link href="Murdoch%20University_files/styles.css" rel="stylesheet" type="text/css">
        <title>
        Murdoch University
        </title>
        <link rel="icon" type="image/png" href="https://static.murdoch.edu.au/precedent/images/favicon-16x16.png" sizes="32x32">
        <link rel="icon" type="image/png" href="https://static.murdoch.edu.au/precedent/images/favicon-32x32.png" sizes="16x16">
        <link rel="icon" type="image/ico" href="https://static.murdoch.edu.au/precedent/images/favicon.ico" sizes="48x48">
        <meta name="Generator" content="Sitefinity 10.1.6532.0 PU">
        <meta class="foundation-mq">
        <link rel ="stylesheet" href="./css/widget.css" />
        <!-- <link rel ="stylesheet" href="./css/ungoal.css"/> -->
        <link href="http://www.cssscript.com/wp-includes/css/sticky.css" rel="stylesheet" type="text/css"/>

        <link rel="stylesheet" type="text/css" href="./css/slick/slick.css"/>

        <link rel="stylesheet" type="text/css" href="./css/slick/slick-theme.css"/>
        <link rel="stylesheet" type="text/css" href="./css/map.css"/>

        <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" />
    </head>
        <div class="sfPublicWrapper" id="PublicWrapper">
            <div id="wrap" class="">
                <header id="header" class="header header--mobile header--narrow" data-page-scroll-element="window" data-header-responsive-offsets="0-0-0|639-69-69|1025-117-69" data-narrow-header="">
                    <a href="#skip-to-content" class="sr-only sr-only-focusable">Skip to main content</a>
                    <div class="header__logo">
                        <div class="site-logo"> <a href="https://www.murdoch.edu.au/" title="Murdoch University home"></a> </div>
                    </div>
                    <nav class="header__top" role="navigation">
                        <div class="row-header">
                            <ul>
                                <li>
                                    <a href="http://our.murdoch.edu.au/Students/" class="link link--white link--fa-r fa-external-link" target="_blank">Current Students</a>
                                </li>
                                <li>
                                    <a target="_blank" class="link link--white link--fa-r fa-external-link" href="http://our.murdoch.edu.au/Staff/">Staff</a>
                                </li>
                                <li>
                                    <a class="link link--white" href="http://www.murdoch.edu.au/contact-us/">Contact us</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/global" class="link link--white">Global</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                    <div id="header-banner" class="header__banner">
                        <div class="row-header">
                            <div class="header__main">
                                <nav class="nav-main" role="navigation">
                                    <ul>
                                        <li>
                                            <a href="curriculum.php">Sustainable Development Goals Mapper</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </header>
                
