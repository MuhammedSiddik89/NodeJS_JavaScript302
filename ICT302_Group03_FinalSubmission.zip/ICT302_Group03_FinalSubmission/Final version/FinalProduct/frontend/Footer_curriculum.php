</div>



<div id="bottom_nav">
	<center>
                    <ul class="bottom_nav_list">
                        <li class="bottom_nav_item">
                            <a style="background-color:rgba(0,0,0,0);" class="bottom_nav_link" href="index.php">
                                <img src="img/icons/arrow-left.svg" width="50" height="50">
                            </a>
                        </li>
                        <li class="bottom_nav_item">
                            <a class="bottom_nav_link" href="index.php">UN Goals</a>
                        </li>
                        <li class="bottom_nav_item">
                            <a class="bottom_nav_link" href="curriculum.php">Curriculum</a>
                        </li>
                        <li class="bottom_nav_item">
                            <a class="bottom_nav_link" href="map.php">Campus Map</a>
                        </li>


                        <li class="bottom_nav_item">
                            <a style="background-color:rgba(0,0,0,0);" class="bottom_nav_link" href="curriculum.php">
                                <img src="img/icons/arrow-right.svg" width="50" height="50">
                            </a>
                        </li>
                    </ul>
	</center>
                </div>
            </main>


            <footer id="footer" class="footer">
                <div class="footer__top">
                    <div class="row-wrap">
                        <div class="site-logo site-logo--footer"> <a href="https://www.murdoch.edu.au/"></a> </div>
                        <div class="footer__social-links">
                            <ul>
                                <li><a class="btn-social--twitter" href="https://twitter.com/murdochuni" target="_blank" title="Twitter">Twitter</a></li>
                                <li><a class="btn-social--facebook" href="https://www.facebook.com/MurdochUniversity/" target="_blank" title="Facebook">Facebook</a></li>
                                <li><a class="btn-social--instagram" href="https://instagram.com/MurdochUniversity/" target="_blank" title="Instagram">Instagram</a></li>
                                <li><a class="btn-social--youtube" href="https://www.youtube.com/user/murdochdigitalmedia" target="_blank" title="YouTube">YouTube</a></li>
                                <li><a class="btn-social--linkedin" href="https://www.linkedin.com/edu/school?id=10232" target="_blank" title="LinkedIn">LinkedIn</a></li>
                            </ul>
                        </div>
                    </div>
                    <nav class="footer__nav" role="navigation" data-accordion-mobile="" data-allow-all-closed="true">
                        <div class="col accordion-item" data-accordion-item="">
                            <a href="#">
                                <h3>Information for</h3>
                            </a>
                            <h3>Information For</h3>
                            <ul data-tab-content="">
                                <li>
                                    <a href="https://www.murdoch.edu.au/study">Future students</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/study/international-students/">International students</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/research-capabilities">Researchers</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/teachers-and-career-advisors">Teachers &amp; career advisors</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/study/undergraduate-students/events-and-resources/parents-and-families">Parents &amp; families</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/alumni-and-giving">Alumni</a>
                                </li>
                                <li>
                                    <a href="http://www.murdoch.edu.au/Support-Murdoch/">Donors</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/industry-and-community">Industry &amp; community</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col accordion-item" data-accordion-item="">
                            <a href="#">
                                <h3>Quick links</h3>
                            </a>
                            <h3>Quick links</h3>
                            <ul data-tab-content="">
                                <li>
                                    <a href="https://www.murdoch.edu.au/study/apply-to-murdoch">Apply to Murdoch</a>
                                </li>
                                <li>
                                    <a target="_blank" href="https://www.murdoch.edu.au/library">Library</a>
                                </li>
                                <li>
                                    <a href="https://my.murdoch.edu.au/" target="_blank">My Murdoch</a>
                                </li>
                                <li>
                                    <a href="http://wwwcoms.murdoch.edu.au/directory/" target="_blank">Staff Directory</a>
                                </li>
                                <li>
                                    <a href="http://www.murdoch.edu.au/Learning-and-Teaching/">Learning &amp; Teaching</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/about-us/work-at-murdoch" target="_blank">Work at Murdoch</a>
                                </li>
                                <li>
                                    <a href="http://www.murdoch.edu.au/Contact-us/Feedback/" target="_blank">Provide feedback</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col accordion-item" data-accordion-item="">
                            <a href="#">
                                <h3>Murdoch Global</h3>
                            </a>
                            <h3>Murdoch Global</h3>
                            <ul data-tab-content="">
                                <li>
                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/perth-campus">Perth</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/rockingham-campus">Rockingham</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/mandurah-campus">Mandurah</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/international-campuses/singapore">Singapore</a>
                                </li>
                                <li>
                                    <a href="https://www.murdoch.edu.au/life-at-murdoch/international-campuses/dubai" target="_blank">Dubai</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col contact-details">
                            <h3>Contact Us</h3>
                            <ul>
                                <li>General enquiries<br>
                                    <a href="tel:+61893606000">+61 8 9360 6000</a>
                                </li>
                                <li><a href="https://www.murdoch.edu.au/contact-us/" class="link link--arrow-r link--red">Future student enquiries</a></li>
                                <li><a href="https://www.murdoch.edu.au/life-at-murdoch/campus-life-culture/security" class="link link--arrow-r link--red">Help &amp; emergencies</a></li>
                                <li>
                                    <address>Perth campus<br>
                                        90 South Street, Murdoch<br>
                                        Western Australia 6150
                                    </address>
                                </li>
                                <li><small>(15 mins from the city centre of Perth)</small></li>
                                <li><a href="https://goo.gl/maps/4cENbz6TsMA2" class="link link--arrow-r link--red"><em aria-hidden="true" class="fa fa-map-marker"></em> Get directions</a></li>
                                <li><a href="https://www.murdoch.edu.au/ResourcePackages/Murdoch/360/Perthcampustour/murdochVT.html" class="link link--arrow-r link--red" target="_blank"><em aria-hidden="true" class="fa fa-map-marker"></em> Campus
                                        virtual tour</a></li>
                                <li><a href="https://www.murdoch.edu.au/life-at-murdoch/maps-and-tours" class="link link--arrow-r link--red"><em aria-hidden="true" class="fa fa-map-marker"></em> Download campus map</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
                <div class="footer__message">
                    <div class="row-wrap">
                        <div class="article  article--row">
                            <p>We acknowledge the Whadjuk people of the Noongar nation as the
                                traditional custodians of this country and its waters and that Murdoch
                                University stands on Noongar country. We pay our respects to Noongar
                                elders past and present, and acknowledge their wisdom and advice in our
                                teaching and cultural knowledge activities.
                            </p>
                            <a href="http://www.murdoch.edu.au/Kulbardi/" class="link link--arrow-r link--red">Kulbardi Aboriginal Centre</a>
                        </div>
                    </div>
                </div>
                <nav class="footer__lower">
                    <div class="row-wrap">
                      <div>
                        <div>
                          <ul data-tab-content="">
                            <li><a target="_blank" href="http://goto.murdoch.edu.au/TEQSANumber">TEQSA number: PRV12163</a></li>
                            <li><a target="_blank" href="http://goto.murdoch.edu.au/CRICOSCode">CRICOS Code: 00125J</a></li>
                            <li><a target="_blank" href="http://goto.murdoch.edu.au/CopyrightNotice">Copyright &amp; Disclaimer</a></li>
                            <li><a target="_blank" href="https://goto.murdoch.edu.au/Privacy">Privacy</a></li>
                            <li>&copy; Murdoch University</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                </nav>
            </footer>
        </div>
    </div>

<!--	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js" > </script>  -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src='js/jquery-3.3.1.js'></script>
	<script src='js/jquery.rwdImageMaps.min.js'></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/utils.js"></script>
	<script src="js/unitcharts.js"></script>
	<script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.bundle.js'></script>
	<script src='https://cdn.jsdelivr.net/gh/emn178/chartjs-plugin-labels/src/chartjs-plugin-labels.js'></script>
<!--    <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js'></script> -->

	<script src="js/Navigation.js"></script>
	<script src="js/UnitDetails.js"></script>
	 <link rel = "stylesheet"   type = "text/css" href = "css/nav_chart.css" />
	 <link rel = "stylesheet"   type = "text/css" href = "css/table.css" />
	<body style="background-color: #FAF5F9; ">
    </body>

</html>