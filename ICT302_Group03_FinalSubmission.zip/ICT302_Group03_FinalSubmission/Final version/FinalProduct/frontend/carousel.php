

<?php
	require "./Header_carousel.php";
	?>
<h1>With The Power Used By Building 245, You Could</h1>
<section class="center slider">
	<div>
		<div class = "carousel_image">
			<div class = "CircleRed">
				<img class = "w_h_100" src="./img/icons/house.svg">
			</div>
		</div>
		<h3>Power  <span class="red"><span id="amnt_house">8</span> Homes</span></h3>
		<br />
		<br />
		<span class="white">How many homes could we power?</span>
		<br />
		<br />
		<li class="white">The number of homes that could be powered with the energy consumption of Building 245, South Street. </li>
		<li class="white">Calculations based on data from the <a style="color:#c00;" href="http://www.abs.gov.au/ausstats/abs@.nsf/Lookup/4670.0main+features100092012">ABS Home Power Use Survey</a> </li>
	</div>
	<div>
		<div class = "carousel_image">
			<div class = "CircleRed">
				<img class = "w_h_100" src="./img/icons/road.svg">
			</div>
		</div>
		<h3>Drive <span class="red"><span id="amnt_miles">318</span> Kilometers</span></h3>
		<br />
		<br />
		<span class="white">How far can you go?</span>
		<br />
		<br />
		<li class="white">The distance that could be driven with power used by Building 245. </li>
		<li class="white">Calculations based on data from the <a style="color:#c00;" href="https://www.environment.gov.au/system/files/resources/5a169bfb-f417-4b00-9b70-6ba328ea8671/files/national-greenhouse-accounts-factors-july-2017.pdf">ABS Emissions Survey</a> </li>
	</div>
	<div>
		<div class = "carousel_image">
			<div class = "CircleRed">
				<img class = "w_h_100" src="./img/icons/light.png">
			</div>
		</div>
		<h3>Provide <span class="red"><span id="amnt_light">318</span> Hours of Light</span></h3>
		<br />
		<br />
		<span class="white">Keeping the lights on</span>
		<br />
		<br />
		<li class="white">Number of hours a standard 500 Lumens lightbulb could be powered for.</li>
		<li class="white">Calculations based on data from the <a style="color:#c00;" href="http://www.energyrating.gov.au/document/factsheet-light-bulb-buyers-guide">Australian Government Energy Rating Guide</a> </li>
	</div>
	<div>
		<div class = "carousel_image">
			<div class = "CircleRed">
				<img class = "w_h_100" src="./img/icons/smoke.svg">
			</div>
		</div>
		<h3>Save <span class="red"><span id="amnt_co2">117</span> kg CO2-e</span> of Carbon Emissions</h3>
		<br />
		<br />
		<span class="white"> Murdoch's Carbon Footprint  </span>
		<br />
		<br />
		<li class="white">Carbon Dioxide is one of the major contributing factors to air pollution and climate change. </li>
		<li class="white">Calculations based on the <a style="color:#c00;" href="https://www.environment.gov.au/system/files/resources/5a169bfb-f417-4b00-9b70-6ba328ea8671/files/national-greenhouse-accounts-factors-july-2017.pdf">Australian Government Emission Factors for WA</a> </li>
	</div>
	<!--<div>
		<img src="http://placehold.it/350x300?text=5">
		</div>

		<div>
		<img src="http://placehold.it/350x300?text=6">
		</div>

		<div>
		<img src="http://placehold.it/350x300?text=7">
		</div>

		<div>
		<img src="http://placehold.it/350x300?text=8">
		</div>

		<div>
		<img src="http://placehold.it/350x300?text=9">
		</div>-->
</section>
<?php
    require "./PHP/DBConnect.php";

    $query = "SELECT * FROM DevicePower WHERE Device='6' or Device='5' or Device='10' or Device='7' or Device='8' or Device='9' ORDER BY Recorded";
    $result = mysqli_query($con, $query);

    if (mysqli_num_rows($result) > 0)
    {
        //output data of each row
        echo '<div style="display:none;">';

        while ($row = mysqli_fetch_assoc($result))
        {
            echo "<div class = 'power_info" . $row["Device"] ."'>";
            echo "<date>" . substr($row["Recorded"], strpos($row["Recorded"], ' ')) . "</date><usage>" .$row["PowerUsageKwh"] ."</usage>";
            echo "</div>";
        }
        echo '</div>';
    }

    require "./PHP/DBClose.php";
?>
<?php
	$leftButton = "./widget.php";
	$scripts = array("https://code.jquery.com/jquery-2.2.0.min.js", "./js/slick/slick.js", "./js/slick/mycarousel.js", "./js/c.js");

	require "./Footer.php";
	?>
