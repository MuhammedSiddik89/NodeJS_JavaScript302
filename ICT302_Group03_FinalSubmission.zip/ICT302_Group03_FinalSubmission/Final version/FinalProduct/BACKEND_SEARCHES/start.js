var requestHandlers = require("./requestHandlers");
//calling appropriate request handler for performing the calculations
requestHandlers.reqUploadTwo();

//reqUploadTwo();


/*
//Connecting all the Node files 
var server = require("./server");
var router = require("./router");
var requestHandlers = require("./requestHandlers");
var http = require("http");
 
var handle = {}; // create handle object literal

//handlers for accessing and routing accordingly
handle["/ajaxPageswitch.js"] = requestHandlers.pageHashing;
handle["/"] = requestHandlers.showHomePage;
handle["/index.html"] = requestHandlers.showHomePage;
handle["/stylesheet.css"] = requestHandlers.styleSheet;

//when the forms are submitted this handlers are executed

handle["/upload2"] = requestHandlers.reqUploadTwo;

// pass handle object (and route function) to server
server.startServer(router.route, handle);
*/